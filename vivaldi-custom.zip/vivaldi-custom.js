// After any edits, initiate the vivaldi-custom.bat file to update Vivaldi Browser files.

(function() {

  "use strict";

  const 
  // Increase time if toolbars require more time to properly load on browser start up
        initializeDelay = 1000,
  //
  // Background images, label text and tooltips.
        clearIcon = "background: url(/style/delete.png) center no-repeat",
        closeIcon = "background: url(/style/close.png) center no-repeat",
        optionsIcon = "background: url(/style/options.png) center no-repeat",
        positionIcon = "background: url(/style/position.png) center no-repeat",
        reloadHeaderIcon = "background: url(/style/reload.png) center no-repeat",
        restartIcon = "background: url(/style/restart.png) center no-repeat",
        spinner1Icon = "background: url(/style/spinner1.png) center no-repeat !important;",
        spinner2Icon = "background: url(/style/spinner2.gif) center no-repeat !important;",
        spinner3Icon = "background: url(/style/spinner3.gif) center no-repeat !important;",
        favIntervalText = "Fav Interval",
        resizeDelayText = "Resize Delay",
        homeAsRestartTooltip = "Restart browser",
        optionsCloseTooltip = "Closes options menu",
        optionsMenuTooltip = "Open/Close Options Menu",
        optionsMenuPositionTooltip = "Repositions menu: Top Left - Top Center - Top Right - Centered",
        reloadHeaderTooltip = "Reloads header back to user preferences",
        label1Tooltip = "Replaces bookmark folders wtih custom icon",
        span1Text = "Bookmark Folder Custom Icon",
        label2Tooltip = "Button popup boxes with arrow pointer",
        span2Text = "Button Popup Arrow Box",
        label3Tooltip = "Show the day of the week in clock before month",
        span3aText = "Day Of Week In Clock",
        button3Tooltip = "Toggle day format short/long name w/wo year",
        button3Text = "Format",
        label4Tooltip = "In Settings > General > Homepage >\nSpecific Page > enter vivaldi://restart",
        span4Text = "Home Button To Restart Button",
        label5Tooltip = "Displays site favicon in urlbar",
        span5Text = "Site Favicon In Urlbar",
        label6Tooltip = "Tab close buttons are larger",
        span6Text = "Tab Close Button Expanded",
        label7Tooltip = "Moves clicked/active tab to first position in tabbar",
        span7Text = "Tab Moves To First Position",
        label8Tooltip = "Footer/Statusbar moves to top position when tabbar on bottom",
        span8Text = "Tabbar On Bottom In Header",
        button9Tooltip = "Click to advance input value\nValue 0 for browser default spinner",
        span9Text = "Tab Spinner Style",
        span10aLabel = "Toolbar alignment top to bottom",
        span10aTooltip = "Increase time to acquire site favicon before sending to urlbar",
        span10bTooltip = "Increase time for toolbars to properly load after exiting fullscreen mode",
        input11Tooltip = "Moveable Toolbars: .UrlBar, .bookmark-bar, footer\nInsert selectors with buttons below in order from\nleft/top to right/bottm. Will ignore duplicate entries",
        span11aTooltip = "Clear input field",
        button12aTooltip = "Click to insert selector\nWill ignore duplicate entries",
        button12bTooltip = "Click to insert selector\nWill ignore duplicate entries",
        button12cTooltip = "Click to insert selector\nWill ignore duplicate entries",
        dayNameAbbr = 'Sun.,Mon.,Tue.,Wed.,Thu.,Fri.,Sat.',
        dayNameLong = 'Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday',
        dayAbbr = dayNameAbbr.split(','),
        dayLong = dayNameLong.split(',');

  let buttonPopup,
      closeButton,
      dayFormat,
      favInterval,
      favInUrl,
      favTimer,
      folderIcon,
      homeRestart,
      list,
      moveActiveTab,
      positionOptionsMenu,
      resizeDelay,
      showDay,
      spinnerStyle,
      tabsOnBottom,
      toolbarList;

  function $c(type, attr, evls) {
    let node = document.createElement(type);
    if (attr && typeof attr === "object") {
      for (let prop in attr) {
        if (typeof node[prop] === "undefined") 
          node.setAttribute(prop, attr[prop]);
        else node[prop] = attr[prop];
    } }
    if (evls) for (let i = 0; i < evls.length; i++) {
      let evl = evls[i];
      node.addEventListener(evl.type, evl.fn);
    }
    return node;
  }

  function $i(newNode, refNode) {
    if (refNode.nextSibling) 
      return refNode.parentNode.insertBefore(newNode, refNode.nextSibling);
    return refNode.parentNode.appendChild(newNode);
  }

  function $q(el, all) {
    if (all) return document.querySelectorAll(el);
    return document.querySelector(el);
  }

  function initialize() {
    let browser = $q("#browser"),
        main = $q("#main"),
        tabs = $q(".tab-strip"),
        res = $q(".resize");
    try {
      chrome.storage.local.get(['buttonPopupKey'], result => {
        buttonPopup = result.buttonPopupKey;
        if (buttonPopup) {
          browser.setAttribute("custom-popup", true);
          customPopup(buttonPopup);
        } else browser.removeAttribute("custom-popup");
      });
      chrome.storage.local.get(['closeButtonKey'], result => {
        closeButton = result.closeButtonKey;
        if (closeButton) {
          browser.setAttribute("custom-close", true);
          customClose(closeButton);
        } else browser.removeAttribute("custom-close");
      });
      chrome.storage.local.get(['dayFormatKey'], result => {
        dayFormat = result.dayFormatKey;
        if (showDay) browser.setAttribute("show-day", dayFormat);
        else browser.removeAttribute("show-day");
      });
      chrome.storage.local.get(['favIntervalKey'], result => {
        favInterval = result.favIntervalKey;
      });
      chrome.storage.local.get(['favInUrlKey'], result => {
        favInUrl = result.favInUrlKey;
        if (favInUrl) {
          browser.setAttribute("fav-in-url", true);
          favImage(favInUrl);
        } else browser.removeAttribute("fav-in-url");
      });
      chrome.storage.local.get(['folderIconKey'], result => {
        folderIcon = result.folderIconKey;
        if (folderIcon) {
          browser.setAttribute("custom-folder", true);
          customFolder(folderIcon);
        } else browser.removeAttribute("custom-folder");
      });
      chrome.storage.local.get(['homeRestartKey'], result => {
        homeRestart = result.homeRestartKey;
        if (homeRestart) homeToRestart(homeRestart);
      });
      chrome.storage.local.get(['moveActiveTabKey'], result => {
        moveActiveTab = result.moveActiveTabKey;
        if (moveActiveTab) moveTab(moveActiveTab);
      });
      chrome.storage.local.get(['positionOptionsMenuKey'], result => {
        positionOptionsMenu = result.positionOptionsMenuKey;
      });
      chrome.storage.local.get(['resizeDelayKey'], result => {
        resizeDelay = result.resizeDelayKey;
      });
      chrome.storage.local.get(['showDayKey'], result => {
        showDay = result.showDayKey;
        if (showDay) browser.setAttribute("show-day", true);
        else browser.removeAttribute("show-day");
      });
      chrome.storage.local.get(['spinnerStyleKey'], result => {
        spinnerStyle = result.spinnerStyleKey;
        if (spinnerStyle) {
          browser.setAttribute("custom-spinner", spinnerStyle);
          customSpinner(spinnerStyle);
        } else browser.removeAttribute("custom-spinner");
      });
      chrome.storage.local.get(['tabsOnBottomKey'], result => {
        tabsOnBottom = result.tabsOnBottomKey;
        if (tabsOnBottom) {
          browser.setAttribute("tabs-on-bottom", true);
          main.insertBefore(tabs, main.lastChild);
          tabbarToggle(tabsOnBottom);
        } else {
          browser.removeAttribute("tabs-on-bottom");
          res.appendChild(tabs);
        }
      });
      chrome.storage.local.get(['toolbarListKey'], result => {
        toolbarList = result.toolbarListKey;
        if (toolbarList) getToolbarList(toolbarList);
      });
      aDayHolder();
      optionsMenu();
      reloadHeader();
      removeDupes("aDay");
    } catch(ex) {}
    buttonPopupListener();
  }

  function aDay(int) {
    let date = new Date(),
        dy = date.getDay(),
        w = dayAbbr[dy],
        ww = dayLong[dy],
        yyyy = date.getFullYear();
    switch (int) {
      case "1": return w;
      case "2": return ww;
      case "3": return w + "\u2002" + yyyy;
      case "4": return ww + "\u2002" + yyyy;
  } }

  function aDayFormat() {
    let inp = $q("#input3"),
        sp = $q("#dayOfWeek");
    if (!showDay) return;
    inp.value = dayFormat;
    if (inp.value == 4) dayFormat = "1";
    else if (inp.value == 1) dayFormat = "2";
    else if (inp.value == 2) dayFormat = "3";
    else dayFormat = "4";
    chrome.storage.local.set({dayFormatKey: dayFormat});
    sp.textContent = aDay(dayFormat);
  }

  function aDayHolder() {
    let sp = $c("span", {id: "dayOfWeek", className: "aDay"}),
        cb = $q(".ClockButton > button");
    sp.textContent = aDay(dayFormat);
    cb.insertBefore(sp, cb.lastChild);
    cb.insertBefore(ip, cb.lastChild);
    removeDupes("aDay");
  }

  function buttonPopupListener() {
    let statusBar = $q(".toolbar-statusbar");
    try {
      for (let i = 0; i < statusBar.childNodes.length; i++)
        statusBar.childNodes[i].onclick = () =>
          setTimeout(() => buttonPopupPosition(), 20);
    } catch(ex) {}
  }

  function buttonPopupPosition() {
    let main = $q("#main"),
        footer = $q("footer"),
        footerHeight = footer.offsetHeight,
        footerTop = footer.offsetTop,
        popup = $q(".button-popup");
    try {
      if (main.nextSibling === footer) {
        popup.setAttribute("position", "bottom");
        popup.style.top = "auto";
        popup.style.bottom = (footerHeight + 6) + "px";
      } else {
        popup.setAttribute("position", "top");
        popup.style.bottom = "auto";
        if ($q(".topmenu")) 
          popup.style.top = (footerTop + footerHeight + 66) + "px";
        else {
          if (tabsOnBottom) popup.style.top = (footerHeight + 3) + "px";
          else popup.style.top = (footerTop + footerHeight + 33) + "px";
      } }
    } catch(ex) {}
  }

  function customClose(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-close", true);
      else browser.removeAttribute("custom-close");
    } catch(ex) {}
  }

  function customFolder(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-folder", true);
      else browser.removeAttribute("custom-folder");
    } catch(ex) {}
  }

  function customPopup(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-popup", true);
      else browser.removeAttribute("custom-popup");
    } catch(ex) {}
  }

  function customSpinner(e) {
    let browser = $q("#browser");
    try {
      if (e > "0" && e < "4") browser.setAttribute("custom-spinner", e);
      else browser.removeAttribute("custom-spinner");
    } catch(ex) {}
  }

  function favImage(e) {
    let browser = $q("#browser"),
        field = $q(".UrlField"),
        img = $c("img", {id: "favImg"});
    try {
      if ($q("#favImg")) {
        field.removeChild(img);
        return;
      }
      if (e) {
        browser.setAttribute("fav-in-url", true);
        field.insertBefore(img, field.firstChild);
        getCurrentTabUpdated();
      } else browser.removeAttribute("fav-in-url");
    } catch(ex) {}
  }

  function getCurrentTab() {
    let field = $q(".UrlField"),
        img = $q("#favImg"),
        sp = $q("#dayOfWeek");
    try {
      sp.textContent = aDay(dayFormat);
      if (!favInUrl) {
        field.removeChild(img);
        return;
      }
      chrome.tabs.query({currentWindow: true, active: true}, tabs => {
        if (tabs[0].title.match(/^Extensions$/))
          img.src = "/style/extensions.png";
        else if (tabs[0].title.match(/Settings$/))
          img.src = "/style/settings.png";
        else if (tabs[0].title.match(/^Start Page$/))
          img.src = "/style/star.png";
        else if (tabs[0].title.match(/^Installed Userscripts$/))
          img.src = "/style/tampermonkey16.png";
        else if (tabs[0].title.match(/https:\/\/dmvapp/))
          img.src = "/style/dmv.png";
        else if (tabs[0].title.match(/YouTube TV$/))
          img.src = "/style/youtubetv.png";
        else if (tabs[0].url.match(/http:\/\/custombuttons/))
          img.src = "/style/custombuttons.png";
        else if (tabs[0].url.match(/https:\/\/www\.aarpmedicareplans/))
          img.src = "/style/united.png";
        else if (tabs[0].favIconUrl === "") 
          img.src = "/style/page.png";
        else 
          img.src = tabs[0].favIconUrl;
      });
    } catch(ex) {}
  }

  function getCurrentTabUpdated() {
    favTimer = setInterval(() => getCurrentTab(), favInterval);
  }

  function getToolbarList(e) {
    e = e.split(",");
    for (let i = e.length - 1; i >= 0; i--) 
      main.insertBefore($q(e[i]), main.firstChild);
    resetHeader();
  }

  function homeToRestart(e) {
    let homeBtn = $q("button[title='Go to homepage']"),
        homeBtn2 = $q("button[title='Restart browser']"),
        homeBtnImg = $q("button[title='Go to homepage'] svg"),
        homeBtnImg2 = $q("button[title='Restart browser'] svg"),
        homeBtnPath = $q("button[title='Go to homepage'] svg > path"),
        homeBtnPath2 = $q("button[title='Restart browser'] svg > path");
    try {
      if (e) {
        homeBtn.id = "restart-browser";
        homeBtn.className = "ToolbarButton-Button custom-button";
        homeBtn.title = homeAsRestartTooltip;
        homeBtnImg.style = restartIcon;
        homeBtnPath.style.display = "none";
      } else {
        homeBtn2.removeAttribute("id");
        homeBtn2.className = "ToolbarButton-Button";
        homeBtn2.title = "Go to homepage";
        homeBtnImg2.removeAttribute("style");
        homeBtnPath2.style.display = "block";
      }
    } catch(ex) {}
  }

  function moveTab(e) {
    let browser = $q("#browser");
    try {
      chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
      if (moveActiveTab) {
        browser.setAttribute("move-tab", true);
        chrome.tabs.query({currentWindow: true, active: true}, tabs =>
          chrome.tabs.move(tabs[0].id, {index: 0}));
      } else browser.removeAttribute("move-tab");
    } catch(ex) {}
  }

  function moveTabPosition(e) {
    if (!moveActiveTab) return;
    try {
      chrome.tabs.move(e.tabId, {index: 0});
    } catch (ex) {
      if (ex == "Error: Tabs can't be edited right now.")
        setTimeout(() => moveTabPosition(e), 50);
  } }

  function optionsMenu() {
    let date = new Date(),
        divX = $c("div", {id: "options", className: "button-toolbar"}),
        divY = $c("div", {id: "options-menu", className: "options-menu-popup"}),
        browser = $q("#browser"),
        statusBar = $q(".toolbar-statusbar");
    if ($q("#options-button")) return;
    try {
      divX.innerHTML = '\
        <button id="options-button"\
                class="ToolbarButton-Button custom-button"\
                title="'+ optionsMenuTooltip +'"\
                type="button"\
                tabindex="-1">\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 style="'+ optionsIcon +'"/>\
          </span>\
        </button>\
      </div>';
      divY.innerHTML = '\
        <div id="div0">\
          <span>Options Menu</span>\
          <button id="position-menu"\
                  class="button"\
                  style="'+ positionIcon +'"\
                  title="'+ optionsMenuPositionTooltip +'"></button>\
          <input id="input0"\
                 class="input"\
                 type="number"\
                 disabled="true"\
                 value="1"/>\
          <button id="options-menu-close"\
                  class="button"\
                  style="'+ closeIcon +'"\
                  title="'+ optionsCloseTooltip +'"></button>\
        </div>\
        <label id="label1"\
               class="label"\
               title="' + label1Tooltip +'">\
          <input id="input1"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span1"\
                class="span">'+ span1Text +'</span>\
        </label>\
        <label id="label2"\
               class="label"\
               title="' + label2Tooltip +'">\
          <input id="input2"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span2"\
                class="span">'+ span2Text +'</span>\
        </label>\
        <label id="label3"\
               class="label"\
               title="'+ label3Tooltip +'">\
          <input id="input3"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span3a"\
                class="span">'+ span3aText +'</span>\
          <button id="button3"\
                  class="button"\
                  title="' + button3Tooltip +'">\
            <span id="span3b"\
                  class="span">'+ button3Text +'</span>\
          </button>\
        </label>\
        <label id="label4"\
               class="label"\
               title="' + label4Tooltip +'">\
          <input id="input4"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span4"\
                class="span">'+ span4Text +'</span>\
        </label>\
        <label id="label5"\
               class="label"\
               title="'+ label5Tooltip +'">\
          <input id="input5"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span5"\
                class="span">'+ span5Text +'</span>\
        </label>\
        <label id="label6"\
               class="label"\
               title="' + label6Tooltip +'">\
          <input id="input6"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span6"\
                class="span">'+ span6Text +'</span>\
        </label>\
        <label id="label7"\
               class="label"\
               title="' + label7Tooltip +'">\
          <input id="input7"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span7"\
                class="span">'+ span7Text +'</span>\
        </label>\
        <label id="label8"\
               class="label"\
               title="' + label8Tooltip +'">\
          <input id="input8"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span8"\
                class="span">'+ span8Text +'</span>\
        </label>\
        <span id="span9"\
              class="span span-number">\
          <input id="input9"\
                 class="input"\
                 type="number"\
                 disabled="true"\
                 value="1"/>\
          <button id="button9"\
                  class="button"\
                  title="' + button9Tooltip +'">\
            <span>'+ span9Text +'</span>\
          </button>\
          <span id="span9a">\
            <span>1</span>\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 height="16" width="16"\
                 style="'+ spinner1Icon +'"/>\
            <span>2</span>\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 height="16" width="16"\
                 style="'+ spinner2Icon +'"/>\
            <span>3</span>\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 height="16" width="16"\
                 style="'+ spinner3Icon +'"/>\
          </span>\
        </span>\
        <span id="span10"\
              class="span span-number">\
          <span title="'+ span10aTooltip +'">'+ favIntervalText +'</span>\
          <input id="input10a"\
                 class="input input-timer"\
                 type="number"\
                 value="100"/>\
          <span title="'+ span10bTooltip +'">'+ resizeDelayText +'</span>\
          <input id="input10b"\
                 class="input input-timer"\
                 type="number"\
                 value="100"/>\
        </span>\
        <span id="separator"></span>\
        <span id="span10a">'+ span10aLabel +'</span>\
        <span id="span11"\
               class="span span-text">\
          <input id="input11"\
                 class="input"\
                 type="text"\
                 value=".UrlBar,.bookmark-bar,footer"\
                 spellcheck="false"\
                 title="'+ input11Tooltip +'"/>\
          <span id="span11a"\
                title="'+ span11aTooltip +'">\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 style="'+ clearIcon +'"/>\
          </span>\
        </span>\
        <span id="span12"\
              class="span span-button">\
          <button id="button12a"\
                  class="button"\
                  title="'+ button12aTooltip +'">\
            <span>.UrlBar</span>\
          </button>\
          <button id="button12b"\
                  class="button"\
                  title="'+ button12bTooltip +'">\
            <span>.bookmark-bar</span>\
          </button>\
          <button id="button12c"\
                  class="button"\
                  title="'+ button12cTooltip +'">\
            <span>footer</span>\
          </button>\
        </span>\
      </div>';
      $i(divX, statusBar.childNodes[2]);
      $i(divY, browser.lastChild);
      $q("div#options-menu #input0").value = positionOptionsMenu;
      $q("div#options-menu #input1").checked = folderIcon;
      $q("div#options-menu #input2").checked = buttonPopup;
      $q("div#options-menu #input3").checked = showDay;
      $q("div#options-menu #input4").checked = homeRestart;
      $q("div#options-menu #input5").checked = favInUrl;
      $q("div#options-menu #input6").checked = closeButton;
      $q("div#options-menu #input7").checked = moveActiveTab;
      $q("div#options-menu #input8").checked = tabsOnBottom;
      $q("div#options-menu #input10a").value = favInterval;
      $q("div#options-menu #input10b").value = resizeDelay;
      $q("div#options-menu #input11").value = toolbarList;
      let ip = $q("#options-menu > label > input[type='checkbox']", true);
      for (let i = 0; i < ip.length; i++) 
        ip[i].onclick = e => onOptionsMenu(e.target.id);
      $q("#options-button").onclick = () => onOptions();
      $q("#options-menu-close").onclick = () => onOptions();
      $q("#position-menu").onclick = () => onOptionsMenuButton();
      $q("#button3").onclick = () => aDayFormat();
      $q("#button9").onclick = () => onSpinner();
      $q("#input10a").onchange = e => onOptionsMenu(e.target.id);
      $q("#input10b").onchange = e => onOptionsMenu(e.target.id);
      $q("#span11a").onclick = () => onClearField();
      $q("#button12a").onclick = e => onSelector("button12a");
      $q("#button12b").onclick = e => onSelector("button12b");
      $q("#button12c").onclick = e => onSelector("button12c");
      removeDupes("options-menu-popup");
    } catch(ex) {}
  }

  function onOptions() {
    let browser = $q("#browser");
    if (browser.hasAttribute("options-menu")) browser.removeAttribute("options-menu");
    else browser.setAttribute("options-menu", true);
    onOptionsMenuPosition(positionOptionsMenu);
    removeDupes("options-menu-popup");
  }

  function onOptionsMenu(e) {
    let browser = $q("#browser"),
        el = document.getElementById(e),
        inp = $q("#input9");
    switch (e) {
      case "input1":
        folderIcon = el.checked;
        chrome.storage.local.set({folderIconKey: folderIcon});
        if (folderIcon) {
          customFolder(folderIcon);
          browser.setAttribute("custom-folder", true);
        } else browser.removeAttribute("custom-folder");
        break;
      case "input2":
        buttonPopup = el.checked;
        chrome.storage.local.set({buttonPopupKey: buttonPopup});
        if (buttonPopup) {
          customPopup(buttonPopup);
          browser.setAttribute("custom-popup", true);
        } else browser.removeAttribute("custom-popup");
        break;
      case "input3":
        showDay = el.checked;
        chrome.storage.local.set({showDayKey: showDay});
        if (showDay) browser.setAttribute("show-day", true);
        else browser.removeAttribute("show-day");
        break;
      case "input4":
        homeRestart = el.checked;
        chrome.storage.local.set({homeRestartKey: homeRestart});
        homeToRestart(homeRestart);
       break;
      case "input5":
        favInUrl = el.checked;
        chrome.storage.local.set({favInUrlKey: favInUrl});
        if (favInUrl) {
          favImage(favInUrl);
          browser.setAttribute("fav-in-url", true);
        } else browser.removeAttribute("fav-in-url");
        break;
      case "input6":
        closeButton = el.checked;
        chrome.storage.local.set({closeButtonKey: closeButton});
        if (closeButton) {
          customClose(closeButton);
          browser.setAttribute("custom-close", true);
        } else browser.removeAttribute("custom-close");
        break;
      case "input7":
        moveActiveTab = el.checked;
        chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
        moveTab(moveActiveTab);
       break;
      case "input8":
        tabsOnBottom = el.checked;
        chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
        tabbarToggle(tabsOnBottom);
        break;
      case "input10a":
         favInterval = el.value;
        chrome.storage.local.set({favIntervalKey: favInterval});
        break;
     case "input10b":
        resizeDelay = el.value;
        chrome.storage.local.set({resizeDelayKey: resizeDelay});
        break;
  } }

  function onOptionsMenuButton() {
    let inp = $q("#input0");
    if (inp.value == "1") inp.value = "2";
    else if (inp.value == "2") inp.value = "3";
    else if (inp.value == "3") inp.value = "4";
    else inp.value = "1";
    positionOptionsMenu = inp.value;
    chrome.storage.local.set({positionOptionsMenuKey: positionOptionsMenu});
    onOptionsMenuPosition(positionOptionsMenu);
  }

  function onOptionsMenuPosition(e) {
    let header = $q("#header"),
        headerHeight = header.offsetHeight + 2,
        inner = $q(".inner"),
        innerTop = inner.offsetTop + 2,
        menu = $q("#options-menu"),
        menuHeight = menu.offsetHeight,
        menuWidth = menu.offsetWidth,
        winHeight = window.screen.height,
        winWidth = window.screen.width;
    switch (e) {
      case "1":
        menu.style.top = headerHeight + innerTop + "px";
        menu.style.left = 0;
        break;
      case "2":
        menu.style.top = headerHeight + innerTop + "px";
        menu.style.left = (winWidth / 2) - (menuWidth / 2) + "px";
        break;
      case "3":
        menu.style.top = headerHeight + innerTop + "px";
        menu.style.left = winWidth - menuWidth + "px";
        break;
      case "4":
        menu.style.top = (winHeight / 2) - (menuHeight / 2) + "px";
        menu.style.left = (winWidth / 2) - (menuWidth / 2) + "px";
  } }

  function onClearField() {
    let browser = $q("#browser"),
        footer = $q("footer"),
        inp = $q("#input11");
    inp.value = "";
    toolbarList = ".UrlBar,.bookmark-bar";
    $i(footer, browser.childNodes[1]);
    chrome.storage.local.set({toolbarListKey: toolbarList});
    resetHeader();
    onOptions();
  }

  function onClose() {
    chrome.tabs.onActivated.removeListener(e => moveTabPosition(e));
    chrome.tabs.onHighlighted.removeListener((tabId, changeInfo, tab) =>
      getCurrentTab());
    chrome.tabs.onUpdated.removeListener((tabId, changeInfo, tab) => {
      if (tab.status === "complete") {
        getCurrentTabUpdated();
        clearInterval(favTimer);
      }
    });
  }

  function onResize() {
    let browser = $q("#browser");
    try {
      if (browser.hasAttribute("options-menu")) browser.removeAttribute("options-menu");
      if (!window.fullscreen) resetHeader();
      resetHeader();
      aDayHolder();
      chrome.storage.local.get(['resizeDelayKey'], result => {
        resizeDelay = result.resizeDelayKey;
      });
      if (browser.hasAttribute("options-menu")) browser.removeAttribute("options-menu");
      removeDupes("options-menu-popup");
    } catch(ex) {}
  }

  function onSelector(e) {
    let inp = $q("#input11");
    switch (e) {
      case "button12a":
        let x = ".UrlBar";
        if (inp.value.match(x)) return;
        else if (inp.value === "") inp.value = x;
        else if (inp.value && !inp.value.match("/,$/")) inp.value = inp.value + "," + x;
        else if (inp.value && inp.value.match(/,$/)) inp.value = inp.value + x;
        break;
      case "button12b":
        let y = ".bookmark-bar";
        if (inp.value.match(y)) return;
        else if (inp.value === "") inp.value = y;
        else if (inp.value && !inp.value.match("/,$/")) inp.value = inp.value + "," + y;
        else if (inp.value && inp.value.match(/,$/)) inp.value = inp.value + y;
        break;
      case "button12c":
        let z = "footer";
        if (inp.value.match(z)) return;
        else if (inp.value === "") inp.value = z;
        else if (inp.value && !inp.value.match("/,$/")) inp.value = inp.value + "," + z;
        else if (inp.value && inp.value.match(/,$/)) inp.value = inp.value + z;
        break;
    }
    toolbarList = inp.value;
    chrome.storage.local.set({toolbarListKey: toolbarList});
    resetHeader();
    onOptions();
  }

  function onSpinner() {
    let browser = $q("#browser"),
        inp = $q("#input9");
    if (inp.value == "0") inp.value = "1";
    else if (inp.value == "1") inp.value = "2";
    else if (inp.value == "2") inp.value = "3";
    else inp.value = "0";
    spinnerStyle = inp.value;
    chrome.storage.local.set({spinnerStyleKey: spinnerStyle});
    if (inp.value === "0") browser.removeAttribute("custom-spinner");
    else browser.setAttribute("custom-spinner", spinnerStyle);
  }

  function reloadHeader() {
    let div1 = $c("div", {className: "button-toolbar reload-header"},
        [{type:"click", fn:()=> resetHeader()}]),
        mainBar = $q(".toolbar.toolbar-droptarget.toolbar-mainbar");
    if ($q(".reload-header")) return;
    try {
      div1.innerHTML = '\
        <button id="reload-header" \
                class="ToolbarButton-Button custom-button" \
                title="'+ reloadHeaderTooltip +'" \
                type="button" \
                tabindex="-1">\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 style="'+ reloadHeaderIcon +'"/>\
          </span>\
        </button>';
      mainBar.insertBefore(div1, mainBar.lastChild);
    } catch(ex) {}
  }

  function removeDupes(className) {
    let dupe = document.getElementsByClassName(className);
    if(dupe.length > 1) 
      for(let i = 1; i < dupe.length; i++) 
        dupe[i].parentNode.removeChild(dupe[i]);
  }

  function resetHeader() {
    let browser = $q("#browser"),
        footer = $q("footer"),
        header = $q("#header"),
        main = $q("#main"),
        tabs = $q(".tab-strip");
    try {
      if (toolbarList) {
        let list =  toolbarList.split(",");
        for (let i = list.length - 1; i >= 0; i--)
          main.insertBefore($q(list[i]), main.firstChild);
        if (tabsOnBottom) {
          main.insertBefore(tabs, main.lastChild);
          $i(footer, header.firstChild);
      } }
      homeToRestart(homeRestart);
      reloadHeader();
      optionsMenu();
      $q("#dayOfWeek").textContent = aDay(dayFormat);
      if (browser.hasAttribute("options-menu")) browser.removeAttribute("options-menu");
      removeDupes("aDay");
    } catch(ex) {}
    buttonPopupListener();
  }

  function tabbarToggle(e) {
    let browser = $q("#browser"),
        footer = $q("footer"),
        header = $q("#header"),
        main = $q("#main"),
        res = $q(".resize"),
        tabs = $q(".tab-strip");
    try {
      chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
      if (e) {
        browser.setAttribute("tabs-on-bottom", true);
        main.insertBefore(tabs, main.lastChild);
        $i(footer, header.firstChild);
      } else {
        browser.removeAttribute("tabs-on-bottom");
        if (toolbarList) {
          let list =  toolbarList.split(",");
          for (let i = list.length - 1; i >= 0; i--)
            main.insertBefore($q(list[i]), main.firstChild);
        }
        res.appendChild(tabs);
      }
    } catch(ex) {}
  }

  chrome.storage.local.get(['buttonPopupKey'], result => {
    buttonPopup = result.buttonPopupKey;
    customPopup(buttonPopup);
  });

  chrome.storage.local.get(['closeButtonKey'], result => {
    closeButton = result.closeButtonKey;
    customClose(closeButton);
  });

  chrome.storage.local.get(['dayFormatKey'], result => {
    dayFormat = result.dayFormatKey;
    aDay(dayFormat);
  });

  chrome.storage.local.get(['favIntervalKey'], result => {
    favInterval = result.favIntervalKey;
  });

  chrome.storage.local.get(['favInUrlKey'], result => {
    favInUrl = result.favInUrlKey;
    favImage(favInUrl);
  });

  chrome.storage.local.get(['folderIconKey'], result => {
    folderIcon = result.folderIconKey;
    customFolder(folderIcon);
  });

  chrome.storage.local.get(['homeRestartKey'], result => {
    homeRestart = result.homeRestartKey;
    homeToRestart(homeRestart);
  });

  chrome.storage.local.get(['moveActiveTabKey'], result => {
    moveActiveTab = result.moveActiveTabKey;
    moveTab(moveActiveTab);
  });

  chrome.storage.local.get(['positionOptionsMenuKey'], result => {
    positionOptionsMenu = result.positionOptionsMenuKey;
  });

  chrome.storage.local.get(['resizeDelayKey'], result => {
    resizeDelay = result.resizeDelayKey;
  });

  chrome.storage.local.get(['showDayKey'], result => {
    showDay = result.showDayKey;
  });

  chrome.storage.local.get(['spinnerStyleKey'], result => {
    spinnerStyle = result.spinnerStyleKey;
    customSpinner(spinnerStyle);
  });

  chrome.storage.local.get(['tabsOnBottomKey'], result => {
    tabsOnBottom = result.tabsOnBottomKey;
  });

  chrome.storage.local.get(['toolbarListKey'], result => {
    toolbarList = result.toolbarListKey;
  });

  chrome.tabs.onActivated.addListener(e => moveTabPosition(e));

  chrome.tabs.onHighlighted.addListener((tabId, changeInfo, tab) =>
    getCurrentTab());

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.status === "complete") {
      getCurrentTabUpdated();
      clearInterval(favTimer);
    }
  });

  window.onload = () => setTimeout(() => {
    if (!toolbarList) toolbarList = ".UrlBar,.bookmark-bar";
    chrome.storage.local.get(['dayFormatKey'], result => {
      dayFormat = result.dayFormatKey;
      aDay(dayFormat);
    });
    chrome.storage.local.get(['favIntervalKey'], result => {
      favInterval = result.favIntervalKey;
    });
    chrome.storage.local.get(['moveActiveTabKey'], result => {
      moveActiveTab = result.moveActiveTabKey;
      moveTab(moveActiveTab);
    });
    chrome.storage.local.get(['positionOptionsMenuKey'], result => {
      positionOptionsMenu = result.positionOptionsMenuKey;
    });
    chrome.storage.local.get(['resizeDelayKey'], result => {
      resizeDelay = result.resizeDelayKey;
    });
    chrome.storage.local.get(['showDayKey'], result => {
      showDay = result.showDayKey;
    });
    chrome.storage.local.get(['spinnerStyleKey'], result => {
      spinnerStyle = result.spinnerStyleKey;
      customSpinner(spinnerStyle);
    });
    chrome.storage.local.get(['tabsOnBottomKey'], result => {
      tabsOnBottom = result.tabsOnBottomKey;
      tabbarToggle(tabsOnBottom);
    });
    chrome.storage.local.get(['toolbarListKey'], result => {
      toolbarList = result.toolbarListKey;
      getToolbarList(toolbarList);
    });
    initialize()}, initializeDelay);

  window.onresize = () => setTimeout(() => onResize(), resizeDelay);

  window.ondrop = e => {
    e.preventDefault();
    homeToRestart(homeRestart);
  };

  window.onunload = () => {
    clearInterval(favTimer);
    chrome.storage.local.set({buttonPopupKey: buttonPopup});
    chrome.storage.local.set({closeButtonKey: closeButton});
    chrome.storage.local.set({dayFormatKey: dayFormat});
    chrome.storage.local.set({favIntervalKey: favInterval});
    chrome.storage.local.set({favInUrlKey: favInUrl});
    chrome.storage.local.set({folderIconKey: folderIcon});
    chrome.storage.local.set({homeRestartKey: homeRestart});
    chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
    chrome.storage.local.set({positionOptionsMenuKey: positionOptionsMenu});
    chrome.storage.local.set({resizeDelayKey: resizeDelay});
    chrome.storage.local.set({showDayKey: showDay});
    chrome.storage.local.set({spinnerStyleKey: spinnerStyle});
    chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
    chrome.storage.local.set({toolbarListKey: toolbarList});
    onClose();
  };

})();
