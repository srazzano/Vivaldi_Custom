// After any edits, initiate the vivaldi-custom.bat file to update Vivaldi Browser files.

(function() {

  "use strict";

  const 
        toolbarAlignment = ".toolbar-statusbar, .bookmark-bar, .UrlBar",
  // toolbarAlignment options: .UrlBar, .bookmark-bar, .toolbar-statusbar
  // List in order from left (top position) to right (bottom position).
  // Comma separate entries and space after comma optional.
  // No entry for default position.
  // Use Toggle Tabbar button on statusbar to set Tabbar on Header bottom/top.
  //
        initializeDelay = 750,
  // Increase time if toolbars require more time to properly load on browser start up.
  //
        favInterval = 1000,
  // Allows tab time to aquire site favicon before sending to urlbar.
  //
        resizeDelay = 100,
  // Increase time for toolbars to properly load after exiting fullscreen mode.
  //
        customSpinnerStyle = 1,
  // 1, 2 or 3 displays different custom spinners. Any other integer displays default spinner.
  //
        customButtonPopup = true,
  // Displays an arrow box popup.
  //
        customTabCloseButton = true,
  // Displays a larger custom tab close button.
  //
        customBookmarkFolderIcon = true,
  // Displays a custom bookmark folder icon for folder bookmarks.
  //
        favInUrlbar = true,
  // Displays site favicons in urlbar.
  //
        homeAsRestart = true,
  // If true, sets Home button as Restart Browser function, with 16px icon and tooltip. 
  // Requires following steps: Open Settings > General > STARTUP section, select 
  // Homepage Specific Page radio and enter vivaldi://restart into input textbox.
  //
        reloadHeaderIcon = "background: url(/style/reload.png) center no-repeat",
        restartIcon = "background: url(/style/restart.png) center no-repeat",
        tabbarIcon = "background: url(/style/tabbar.png) center no-repeat",
        homeAsRestartTooltip = "Restart browser",
        reloadHeaderTooltip = "Reload header back to user preferences",
        tabMoveTooltip = "Move clicked/xctive tab activated:",
        tabbarToggleTooltip = "Toggle tabbar bottom/top",
  // Background images and tooltips.
  //
        list = toolbarAlignment.replace(/\s+/g, "")
                               .replace(".toolbar-statusbar", "footer")
                               .split(",");

  var favTimer,
      moveTabOnClick,
      tabsOnBottom;

  function $c(type, attr) {
    let node = document.createElement(type);
    for (let prop in attr) node.setAttribute(prop, attr[prop]);
    return node;
  }

  function $i(newNode, refNode) {
    if (refNode.nextSibling) 
      return refNode.parentNode.insertBefore(newNode, refNode.nextSibling);
    return refNode.parentNode.appendChild(newNode);
  }

  function $q(el, all) {
    if (all) return document.querySelectorAll(el);
    return document.querySelector(el);
  }

  function initialize() {
    window.removeEventListener("load", () => {setTimeout(() => {
      chrome.storage.local.get(['moveTabKey'], result => {
        moveTabOnClick = result.moveTabKey;
        tabMoveOption();
      });
      chrome.storage.local.get(['tabsOnBottomKey'], result => {
        tabsOnBottom = result.tabsOnBottomKey;
        tabbarTogglePosition();
      });
      initialize()}, initializeDelay);
    });
    let browser = $q("#browser"),
        main = $q("#main"),
        tabs = $q(".tab-strip"),
        res = $q(".resize");
    try {
      if (!toolbarAlignment) return;
      for (let i = list.length - 1; i >= 0; i--)
        main.insertBefore($q(list[i]), main.firstChild);
      if (main.lastChild.previousSibling.previousSibling === tabs) 
        browser.setAttribute("tabs-on-bottom", true);
      else browser.removeAttribute("tabs-on-bottom");
      tabsOnBottom ? main.insertBefore(tabs, main.lastChild) : res.appendChild(tabs);
      customClose(customTabCloseButton);
      customFolder(customBookmarkFolderIcon);
      customPopup(customButtonPopup);
      customSpinner(customSpinnerStyle);
      favImageHolder(favInUrlbar);
      homeToRestart(homeAsRestart);
      reloadHeader();
      tabMoveHolder();
      tabbarToggleHolder();
    } catch(ex) {}
    buttonPopupListener();
  }

  function buttonPopupListener() {
    let statusBar = $q(".toolbar-statusbar");
    try {
      for (let i = 0; i < statusBar.childNodes.length; i++)
        statusBar.childNodes[i].addEventListener("click", () =>
          setTimeout(() => buttonPopupPosition(), 100));
    } catch(ex) {}
  }

  function buttonPopupPosition() {
    let main = $q("#main"),
        footer = $q("footer"),
        popup = $q(".button-popup"),
        footerHeight = footer.offsetHeight,
        footerTop = footer.offsetTop;
    try {
      if (main.nextSibling === footer) {
        popup.setAttribute("position", "bottom");
        popup.style.top = "auto";
        popup.style.bottom = (footerHeight + 6) + "px";
      } else {
        popup.setAttribute("position", "top");
        popup.style.bottom = "auto";
        if ($q(".topmenu")) popup.style.top = (footerTop + footerHeight + 65) + "px";
        else {
          if (tabsOnBottom) popup.style.top = (footerHeight + 2) + "px";
          else popup.style.top = (footerTop + footerHeight + 33) + "px";
      } }
    } catch(ex) {}
  }

  function customClose(e) {
    let browser = $q("#browser");
    if (e) browser.setAttribute("custom-close", true);
    else browser.removeAttribute("custom-close");
  }

  function customFolder(e) {
    let browser = $q("#browser");
    if (e) browser.setAttribute("custom-folder", true);
    else browser.removeAttribute("custom-folder");
  }

  function customPopup(e) {
    let browser = $q("#browser");
    if (e) browser.setAttribute("custom-popup", true);
    else browser.removeAttribute("custom-popup");
  }

  function customSpinner(e) {
    let browser = $q("#browser");
    if (e === 1 || e === 2 || e === 3 || e === 4)
      browser.setAttribute("custom-spinner", e);
    else browser.removeAttribute("custom-spinner");
  }

  function favImageHolder(e) {
    if ($q("#favImg")) return;
    let browser = $q("#browser"),
        field = $q(".UrlField"),
        img = $c("img", {id: "favImg"});
    if (e) {
      browser.setAttribute("fav-in-url", true);
      field.insertBefore(img, field.firstChild);
      getCurrentTabUpdated();
    } else browser.removeAttribute("fav-in-url");
  }

  function getCurrentTab() {
    if (!favInUrlbar) return;
    let img = $q("#favImg"),
        fav = $q(".favicon > img");
    try {
      chrome.tabs.query({currentWindow: true, active: true}, tabs => {
        if (tabs[0].title.match(/^Extensions$/))
          img.src = "/style/extensions.png";
        else if (tabs[0].title.match(/Settings$/))
          img.src = "/style/settings.png";
        else if (tabs[0].title.match(/^Installed Userscripts$/))
          img.src = "/style/tampermonkey.png";
        else if (tabs[0].title.match(/https:\/\/dmvapp/))
          img.src = "/style/dmv.png";
        else if (tabs[0].url.match(/http:\/\/custombuttons/))
          img.src = "/style/custombuttons.png";
        else if (tabs[0].url.match(/https:\/\/www\.aarpmedicareplans/))
          img.src = "/style/united.png";
        else if (tabs[0].favIconUrl === "") 
          img.src = "/style/default.png";
        else 
          img.src = tabs[0].favIconUrl;
      });
    } catch(ex) {}
  }

  function getCurrentTabUpdated() {
    favTimer = setInterval(() => getCurrentTab(), favInterval);
  }

  function homeToRestart(e) {
    if (!e) return;
    let homeBtn = $q("button[title='Go to homepage']"),
        homeBtnImg = $q("button[title='Go to homepage'] svg"),
        homeBtnPath = $q("button[title='Go to homepage'] svg > path");
    homeBtn.id = "restart-browser";
    homeBtn.className = "ToolbarButton-Button custom-button";
    homeBtn.title = homeAsRestartTooltip;
    homeBtnImg.style = restartIcon;
    homeBtnPath.style.display = "none";
  }

  function reloadHeader() {
    let div1 = $c("div", {class: "button-toolbar reload-header"}),
        mainBar = $q(".toolbar.toolbar-droptarget.toolbar-mainbar"),
        statusBar = $q(".toolbar-statusbar");
    try {
      if (!$q(".reload-header")) {
        div1.innerHTML = '\
          <button id="reload-header" \
                  class="ToolbarButton-Button custom-button" \
                  title="'+ reloadHeaderTooltip +'" \
                  style="border-radius: 50%" \
                  type="button" \
                  tabindex="-1">\
            <span>\
              <svg xmlns="http://www.w3.org/2000/svg" \
                   style="'+ reloadHeaderIcon +'"/>\
            </span>\
          </button>';
        mainBar.insertBefore(div1, mainBar.lastChild);
        $q("#reload-header").addEventListener("click", () =>
          resetHeader());
      }
    } catch(ex) {}
  }

  function resetHeader() {
    let browser = $q("#browser"),
        header = $q("#header"),
        main = $q("#main"),
        tabs = $q(".tab-strip"),
        footer = $q("footer");
    try {
      if (toolbarAlignment) {
        for (let i = list.length - 1; i >= 0; i--) main.insertBefore($q(list[i]), main.firstChild);
        if (tabsOnBottom) {
          main.insertBefore(tabs, main.lastChild);
          $i(footer, header.firstChild);
      } }
      homeToRestart(homeAsRestart);
      reloadHeader();
      tabMoveHolder();
      tabbarToggleHolder();
    } catch(ex) {}
    buttonPopupListener();
  }

  function tabMoveHolder() {
    let div2 = $c("div", {class: "button-toolbar move-tab"}),
        statusBar = $q(".toolbar-statusbar"),
        bool = " " + moveTabOnClick.toString().toUpperCase();
    try {
      if (!$q(".move-tab")) {
        div2.innerHTML = '\
          <button id="move-tab-button" \
                  class="ToolbarButton-Button custom-button" \
                  title="'+ tabMoveTooltip + bool +'" \
                  type="button" \
                  tabindex="-1">\
            <span>\
              <svg xmlns="http://www.w3.org/2000/svg"/>\
            </span>\
          </button>';
        $i(div2, statusBar.childNodes[2]);
        $q(".move-tab").addEventListener("click", () => {
          moveTabOnClick = !moveTabOnClick;
          tabMoveOption();
        });
      }
    } catch(ex) {}
  }

  function tabMoveOption() {
    let browser = $q("#browser"),
        btn = $q("#move-tab-button"),
        bool = " " + moveTabOnClick.toString().toUpperCase();
    try {
      chrome.storage.local.set({moveTabKey: moveTabOnClick});
      if (moveTabOnClick) {
        browser.setAttribute("move-tab", true);
        chrome.tabs.query({currentWindow: true, active: true}, tabs =>
          chrome.tabs.move(tabs[0].id, {index: 0}));
      } else browser.removeAttribute("move-tab");
      btn.title = tabMoveTooltip + bool;
    } catch(ex) {}
  }

  function tabMovePosition(e) {
    if (!moveTabOnClick) return;
    try {
      chrome.tabs.move(e.tabId, {index: 0});
    } catch (ex) {
      if (ex == "Error: Tabs can't be edited right now (may be dragging a tab).")
        setTimeout(() => tabMovePosition(e), 50);
  } }

  function tabbarToggleHolder() {
    let div3 = $c("div", {class: "button-toolbar tabs-on-bottom"}),
        statusBar = $q(".toolbar-statusbar");
    try {
      if (!$q(".tabs-on-bottom")) {
        div3.innerHTML = '\
          <button id="tabs-on-bottom-button" \
                  class="ToolbarButton-Button custom-button" \
                  title="'+ tabbarToggleTooltip +'" \
                  type="button" \
                  tabindex="-1">\
            <span>\
              <svg xmlns="http://www.w3.org/2000/svg" \
                   style="'+ tabbarIcon +'"/>\
            </span>\
          </button>';
        $i(div3, statusBar.childNodes[2]);
        $q(".tabs-on-bottom").addEventListener("click", () => {
          tabsOnBottom = !tabsOnBottom;
          tabbarTogglePosition();
        });
      }
      if (tabsOnBottom) tabbarTogglePosition();
    } catch(ex) {}
  }

  function tabbarTogglePosition() {
    let browser = $q("#browser"),
        header = $q("#header"),
        main = $q("#main"),
        res = $q(".resize"),
        tabs = $q(".tab-strip"),
        footer = $q("footer");
    try {
      chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
      if (tabsOnBottom) {
        browser.setAttribute("tabs-on-bottom", true);
        main.insertBefore(tabs, main.lastChild);
        $i(footer, header.firstChild);
      } else {
        browser.removeAttribute("tabs-on-bottom");
        res.appendChild(tabs);
        resetHeader();
      }
    } catch(ex) {}
  }

  function onClose() {
    chrome.tabs.onActivated.removeListener(e => tabMovePosition(e));
    chrome.tabs.onHighlighted.removeListener((tabId, changeInfo, tab) =>
      getCurrentTab());
    chrome.tabs.onUpdated.removeListener((tabId, changeInfo, tab) => {
      if (tab.status === "complete") {
        getCurrentTabUpdated();
        clearInterval(favTimer);
      }
    });
    for (let i = 0; i < statusBar.childNodes.length; i++)
      statusBar.childNodes[i].addEventListener("click", () =>
        setTimeout(() => buttonPopupPosition(), 100));
    $q(".move-tab").removeEventListener("click", () => {
      moveTabOnClick = !moveTabOnClick;
      tabMoveOption();
    });
    $q(".tabs-on-bottom").removeEventListener("click", () => {
      tabsOnBottom = !tabsOnBottom;
      tabbarTogglePosition();
    });
    $q("#reload-header-url").removeEventListener("click", () =>
      resetHeader());
    window.removeEventListener("drop", e => {
      e.preventDefault();
      homeToRestart(homeAsRestart);
      tabMoveHolder();
      tabbarToggleHolder();
    });
    window.removeEventListener("resize", () => setTimeout(() =>
      onResize(), resizeDelay));
    window.removeEventListener("beforeunload", () => {
      chrome.storage.local.set({moveTabKey: moveTabOnClick}); 
      chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
      onClose();
    });
    window.removeEventListener("unload", () => {
      chrome.storage.local.set({moveTabKey: moveTabOnClick});
      chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
      onClose();
    });
  }

  function onResize() {
    if (!window.fullscreen) resetHeader();
  }

  chrome.storage.local.get(['moveTabKey'], result => {
    moveTabOnClick = result.moveTabKey;
    tabMoveOption();
  });
  chrome.storage.local.get(['tabsOnBottomKey'], result =>
    tabsOnBottom = result.tabsOnBottomKey);

  chrome.tabs.onActivated.addListener(e => tabMovePosition(e));
  chrome.tabs.onHighlighted.addListener((tabId, changeInfo, tab) =>
    getCurrentTab());
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.status === "complete") {
      getCurrentTabUpdated();
      clearInterval(favTimer);
    }
  });
  window.addEventListener("load", () => {setTimeout(() => {
    chrome.storage.local.get(['moveTabKey'], result => {
      moveTabOnClick = result.moveTabKey;
      tabMoveOption();
    });
    chrome.storage.local.get(['tabsOnBottomKey'], result => {
      tabsOnBottom = result.tabsOnBottomKey;
      tabbarTogglePosition();
    });
    initialize()}, initializeDelay);
  });
  window.addEventListener("drop", e => {
    e.preventDefault();
    homeToRestart(homeAsRestart);
    tabMoveHolder();
    tabbarToggleHolder();
  });
  window.addEventListener("resize", () => setTimeout(() =>
    onResize(), resizeDelay));
  window.addEventListener("beforeunload", () => {
    chrome.storage.local.set({moveTabKey: moveTabOnClick});
    chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
    onClose();
  });
  window.addEventListener("unload", () => {
    chrome.storage.local.set({moveTabKey: moveTabOnClick});
    chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
    onClose();
  });

})();
