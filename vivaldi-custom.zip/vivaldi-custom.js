/* use strict */

const 
      toolbarAlignment = "footer, bookmark-bar, UrlBar",
// Options: UrlBar, toolbar-extensions, bookmark-bar, footer. Set tabbar in Settings.
// List in order from left (top) to right (bottom) and space between entries optional.
// No entries for default.
//
      initializeDelay = 500,
// Increase initializeDelay time if toolbars require more time to properly load on browser start up.
//
      favInterval = 100,
//
      resizeDelay = 20,
// Increase resizeDelay time if toolbars require more time to properly load after exiting fullscreen mode.
//
      customSpinnerStyle = 1,
// 1, 2 or 3 displays custom spinner. 0 or any other integer displays default spinner.
//
      customButtonPopup = true,
// Displays a custom button popup with arrow.
//
      customCloseButton = true,
// Displays a custom tab close button.
//
      customFolderIcon = true,
// Displays a custom bookmark folder icon.
//
      favInUrlbar = true,
// Displays site favicon in urlbar.
//
      homeAsRestart = true,
// If true, sets Home button as Restart Browser function, with 16px icon and tooltip. 
// Requires following steps: Open Settings > General > STARTUP section, select 
// Homepage Specific Page radio and enter vivaldi://restart into input textbox.
//
      printPageButton = true,
// Displays a Print Page button on footer statusbar 4th icon from left.
//
      reloadHeaderButtonInStatusbar = true,
// Displays a Reload Header button on footer statusbar 5th icon from left, 
// in the event header elements don't align properly after start-up or resize.
//
      reloadHeaderButtonInUrlbar = false,
// Displays a Reload Header button on urlbar in the event header elements don't align properly.
//
      printButton12Icon = "background: url(/style/print12.png) center no-repeat",
      reloadHeaderButton12Icon = "background: url(/style/reload12.png) center no-repeat",
      reloadHeaderButton16Icon = "background: url(/style/reload16.png) center no-repeat; height: 16px; width: 16px;",
      restartButton12Icon = "background: url(/style/restart12.png) center no-repeat",
      restartButton16Icon = "background: url(/style/restart16.png) center no-repeat";

var favTimer;

function $c(type, attr) {
  let node = document.createElement(type);
  for (let prop in attr) node.setAttribute(prop, attr[prop]);
  return node;
}

function $q(el, all) {
  if (all) return document.querySelectorAll(el);
  return document.querySelector(el);
}

function initialize() {
  window.removeEventListener("load", () => {setTimeout(() => {initialize()}, initializeDelay)});
  let browser = $q("#browser"),
      main = $q("#main"),
      list = toolbarAlignment.replace(/\s+/g, "").split(",");
  try {
    if (toolbarAlignment) {
      for (let i = list.length - 1; i >= 0; i--) {
        if (list[i] === "footer") list[i] = list[i];
        else list[i] = "." + list[i];
        main.insertBefore($q(list[i]), main.firstChild);
    } }
    customClose(customCloseButton);
    customFolder(customFolderIcon);
    customPopup(customButtonPopup);
    customSpinner(customSpinnerStyle);
    favImageHolder(favInUrlbar);
    homeToRestartButton(homeAsRestart);
    printButton(printPageButton);
    reloadHeaderButtonToStatusbar(reloadHeaderButtonInStatusbar);
    reloadHeaderButtonToUrlbar(reloadHeaderButtonInUrlbar);
  } catch(ex) {}
  buttonPopupListener();
}

function buttonPopupListener() {
  let statusBar = $q(".toolbar-statusbar");
  try {
    for (let i = 0; i < statusBar.childNodes.length; i++)
      statusBar.childNodes[i].addEventListener("click", () => {buttonPopupPosition()});
  } catch(ex) {}
}

function buttonPopupPosition() {
  let main = $q("#main"),
      footer = $q("footer"),
      popup = $q(".button-popup"),
      footerHeight = footer.offsetHeight,
      footerTop = footer.offsetTop;
  try {
    if (main.nextSibling === footer) {
      popup.setAttribute("position", "bottom");
      popup.style.top = "auto";
      popup.style.bottom = (footerHeight + 8) + "px";
    } else {
      popup.setAttribute("position", "top");
      popup.style.bottom = "auto";
      if ($q(".topmenu")) popup.style.top = (footerTop + footerHeight + 63) + "px";
      else popup.style.top = (footerTop + footerHeight + 34) + "px";
    }
  } catch(ex) {}
}

function customClose(e) {
  let browser = $q("#browser");
  if (e) browser.setAttribute("custom-close", true);
  else browser.removeAttribute("custom-close");
}

function customFolder(e) {
  let browser = $q("#browser");
  if (e) browser.setAttribute("custom-folder", true);
  else browser.removeAttribute("custom-folder");
}

function customPopup(e) {
  let browser = $q("#browser");
  if (e) browser.setAttribute("custom-popup", true);
  else browser.removeAttribute("custom-popup");
}

function customSpinner(e) {
  let browser = $q("#browser");
  if (e === 1 || e === 2 || e === 3) browser.setAttribute("custom-spinner", e);
  else browser.removeAttribute("custom-spinner");
}

function favImageHolder(e) {
  if ($q("#favImg")) return;
  if (e) {
    let browser = $q("#browser"),
        field = $q(".UrlField"),
        img = $c("img", {id: "favImg"});
    browser.setAttribute("favinurl", true);
    field.insertBefore(img, field.firstChild);
    getCurrentTabUpdated();
  } else browser.removeAttribute("favinurl");
}

function getCurrentTab() {
  if (!favInUrlbar) return;
  let img = $q("#favImg");
  chrome.tabs.query({currentWindow: true, active: true}, tabs => {
    if (tabs[0].favIconUrl) img.src = tabs[0].favIconUrl;
    else img.src = "/style/default16.png";
  });
}

function getCurrentTabHighlighted() {
  getCurrentTab();
}

function getCurrentTabUpdated() {
  favTimer = setInterval(() => {getCurrentTab()}, favInterval);
}

function homeToRestartButton(e) {
  if (!e) return;
  let homeBtn = $q("button[title='Go to homepage']"),
      homeBtnImg = $q("button[title='Go to homepage'] svg"),
      homeBtnPath = $q("button[title='Go to homepage'] svg > path");
  homeBtn.id = "restart-browser";
  homeBtn.className = "ToolbarButton-Button custom-button";
  homeBtn.title = "Restart Browser";
  homeBtnImg.style = restartButton16Icon;
  homeBtnPath.style.display = "none";
}

function printButton(e) {
  if (!e) return;
  let div0 = $c("div"),
      statusBar = $q(".toolbar-statusbar");
  try {
    if (!$q(".mod-print-page")) {
      div0.classList.add('button-toolbar', 'mod-print-page');
      div0.innerHTML = '\
        <button id="print-button" \
                class="ToolbarButton-Button custom-button" \
                title="Print Page" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 viewBox="0 0 16 16" \
                 style="' + printButton12Icon  +'"/>\
          </span>\
        </button>';
      statusBar.insertBefore(div0, statusBar.childNodes[2].nextSibling);
      $q("#print-button").addEventListener("click", () => {printPage()});
    }
  } catch(ex) {}
}

function printPage() {
  chrome.tabs.query({currentWindow: true, active: true}, tabs => {
    vivaldi.utilities.print(tabs[0].id);
  });
}

function reloadHeaderButtonToStatusbar(e) {
  if (!e) return;
  let div2 = $c("div", {class: "button-toolbar reload-header-statusbar"}),
      statusBar = $q(".toolbar-statusbar");
  try {
    if (!$q(".reload-header-statusbar")) {
      div2.innerHTML = '\
        <button id="reload-header-statusbar" \
                class="ToolbarButton-Button custom-button" \
                title="Reload Header" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 viewBox="0 0 16 16" \
                 style="' + reloadHeaderButton12Icon +'"/>\
          </span>\
        </button>';
      if ($q("#print-button")) statusBar.insertBefore(div2, statusBar.childNodes[3].nextSibling);
      else statusBar.insertBefore(div2, statusBar.childNodes[2].nextSibling);
      $q("#reload-header-statusbar").addEventListener("click", () => {initialize()});
    }
  } catch(ex) {}
}

function reloadHeaderButtonToUrlbar(e) {
  if (!e) return;
  let div1 = $c("div", {class: "button-toolbar reload-header-url"}),
      mainBar = $q(".toolbar.toolbar-droptarget.toolbar-mainbar");
  try {
    if (!$q(".reload-header-url")) {
      div1.innerHTML = '\
        <button id="reload-header-url" \
                class="ToolbarButton-Button custom-button" \
                title="Reload Header" \
                style="border-radius: 50%" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 viewBox="0 0 26 26" \
                 style="' + reloadHeaderButton16Icon +'"/>\
          </span>\
        </button>';
      mainBar.insertBefore(div1, mainBar.lastChild);
      $q("#reload-header-url").addEventListener("click", () => {initialize()});
    }
  } catch(ex) {}
}

function onClose() {
  chrome.tabs.onHighlighted.removeListener((tabId, changeInfo, tab) => {
    getCurrentTabHighlighted();
  });
  chrome.tabs.onUpdated.removeListener((tabId, changeInfo, tab) => {
    if (tab.status === "complete") {getCurrentTabUpdated(); clearInterval(favTimer)};
  });
  $q("#reload-header-url").removeEventListener("click", () => {initialize()});
  $q("#reload-header-statusbar").removeEventListener("click", () => {initialize()});
  $q("#print-button").removeEventListener("click", () => {printPage()});
  window.removeEventListener("drop", e => {e.preventDefault(); homeToRestartButton(homeAsRestart)});
  window.removeEventListener("resize", () => {setTimeout(() => {onResize()}, resizeDelay)});
  window.removeEventListener("unload", () => {onClose()});
}

function onResize() {
  if (!window.fullscreen) initialize();
}

chrome.tabs.onHighlighted.addListener((tabId, changeInfo, tab) => {
  getCurrentTabHighlighted();
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.status === "complete") {getCurrentTabUpdated(); clearInterval(favTimer)};
});
window.addEventListener("drop", e => {e.preventDefault(); homeToRestartButton(homeAsRestart)});
window.addEventListener("load", () => {setTimeout(() => {initialize()}, initializeDelay)});
window.addEventListener("resize", () => {setTimeout(() => {onResize()}, resizeDelay)});
window.addEventListener("unload", () => {onClose()});