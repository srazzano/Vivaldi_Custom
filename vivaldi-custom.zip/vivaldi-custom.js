const alignDelay = 1000, // (1) Increase alignDelay time if toolbars require more time to properly load on browser start up.
      resizeDelay = 100, // (2) Increase resizeDelay time if toolbars require more time to properly load after exiting fullscreen mode.
      reloadHeaderButtonInUrlbar = false, // (3) Display a Reload Header button on urlbar in the event header elements don't align properly.
      reloadHeaderButtonInStatusbar = true, // (4) Display a Reload Header button on statusbar 5th icon from left, if header elements don't align properly.
      printPageButton = true, // (5) Display a Print Page button on statusbar 4th icon from left.
      homeAsRestart = true, // (6) If true, sets Home button as Restart Browser function, with 16px icon and tooltip. Requires following steps:
                            // Open Settings > General > STARTUP section, select Homepage Specific Page radio and enter vivaldi://restart/ into input textbox.
      toolbarsPosition = 5, // (7) Tabs always on top.
                            // Toolbars listed from top to bottom.
                            // 0 = browser default toolbar positions.
                            // 1 = urlbar > bookmarks > statusbar, 2 = urlbar > statusbar > bookmarks, 3 = bookmarks > statusbar > urlbar
                            // 4 = bookmarks > urlbar > statusbar, 5 = statusbar > bookmarks > urlbar, 6 = statusbar > urlbar > bookmarks
      printButtonIcon = "background: url(/style/print.png) center no-repeat",
      reloadHeaderButtonLargeIcon = "background: url(/style/reload-large.png) center no-repeat",
      reloadHeaderButtonSmallIcon = "background: url(/style/reload-small.png) center no-repeat",
      restartButtonIcon = "background: url(/style/restart.png) center no-repeat";

function $q(el, all) {
  if (all) return document.querySelectorAll(el);
  return document.querySelector(el);
}

function alignToolbars() {
  window.removeEventListener("load", () => {setTimeout(() => {alignToolbars()}, alignDelay)});
  let main = $q("#main"),
      urlBar = $q("div.UrlBar"),
      bookmarksBar = $q("div.bookmark-bar"),
      footer = $q("footer"),
      statusBar = $q("div.toolbar-statusbar");
  try {
    switch (toolbarsPosition) {
      case 1:
        main.insertBefore(footer, main.firstChild);
        main.insertBefore(bookmarksBar, main.firstChild);
        main.insertBefore(urlBar, main.firstChild);
       break;
      case 2:
        main.insertBefore(bookmarksBar, main.firstChild);
        main.insertBefore(footer, main.firstChild);
        main.insertBefore(urlBar, main.firstChild);
        break;
      case 3:
        main.insertBefore(urlBar, main.firstChild);
        main.insertBefore(footer, main.firstChild);
        main.insertBefore(bookmarksBar, main.firstChild);
        break;
      case 4:
        main.insertBefore(footer, main.firstChild);
        main.insertBefore(urlBar, main.firstChild);
        main.insertBefore(bookmarksBar, main.firstChild);
        break;
      case 5:
        main.insertBefore(urlBar, main.firstChild);
        main.insertBefore(bookmarksBar, main.firstChild);
        main.insertBefore(footer, main.firstChild);
        break;
      case 6:
        main.insertBefore(bookmarksBar, main.firstChild);
        main.insertBefore(urlBar, main.firstChild);
        main.insertBefore(footer, main.firstChild);
        break;
      default:
    }
    if (homeAsRestart) homeToRestartButton();
    if (printPageButton) printButton();
    if (reloadHeaderButtonInStatusbar) reloadHeaderButtonToStatusbar();
    if (reloadHeaderButtonInUrlbar) reloadHeaderButtonToUrlbar();
  } catch(ex) {}
  buttonPopupListener();
}

function buttonPopupListener() {
  let statusBar = $q("footer > div.toolbar-statusbar");
  try {
    for (let i = 0; i < statusBar.childNodes.length; i++)
      statusBar.childNodes[i].addEventListener("click", () => {buttonPopupPosition()});
  } catch(ex) {}
}

function buttonPopupPosition() {
  let main = $q("#main"),
      footer = $q("footer"),
      popup = $q("div.button-popup"),
      footerHeight = footer.offsetHeight,
      footerTop = footer.offsetTop;
  try {
    if (main.nextSibling === footer) {
      popup.setAttribute("position", "bottom");
      popup.style.top = "auto";
      popup.style.bottom = (footerHeight + 6) + "px";
    } else {
      popup.setAttribute("position", "top");
      popup.style.bottom = "auto";
      popup.style.top = (footerTop + footerHeight + 39) + "px";
    }
  } catch(ex) {}
}

function homeToRestartButton() {
  let homeBtn = $q("button[title='Go to homepage']"),
      homeBtnImg = $q("button[title='Go to homepage'] svg"),
      homeBtnPath = $q("button[title='Go to homepage'] svg > path");
  homeBtn.id = "restart-browser";
  homeBtn.className = "ToolbarButton-Button custom-button";
  homeBtn.title = "Restart Browser";
  homeBtnImg.style = restartButtonIcon;
  homeBtnPath.style.display = "none";
}

function printButton() {
  let div0 = document.createElement("div"),
      statusBar = $q("footer > div.toolbar-statusbar");
  try {
    if (!$q(".mod-print-page")) {
      div0.classList.add('button-toolbar', 'mod-print-page');
      div0.innerHTML = '\
        <button id="print-button" \
                class="ToolbarButton-Button custom-button" \
                title="Print Page" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg viewBox="0 0 16 16" \
                 style="' + printButtonIcon  +'" >\
            </svg>\
          </span>\
        </button>';
      statusBar.insertBefore(div0, statusBar.childNodes[2].nextSibling);
      $q("#print-button").addEventListener("click", () => {printPage()});
    }
  } catch(ex) {}
}

function printPage() {
  chrome.tabs.query({currentWindow: true, active: true}, tabs => {vivaldi.utilities.print(tabs[0].id)});
}

function reloadHeaderButtonToUrlbar() {
  let div1 = document.createElement("div"),
      mainBar = $q("div.toolbar.toolbar-droptarget.toolbar-mainbar.toolbar-large");
  try {
    if (!$q(".reload-header-url")) {
      div1.className = "button-toolbar reload-header-url";
      div1.innerHTML = '\
        <button id="reload-header-url" \
                class="ToolbarButton-Button custom-button" \
                title="Reload Header" \
                style="border-radius: 50%" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg viewBox="0 0 26 26" \
                 style="' + reloadHeaderButtonLargeIcon +'" >\
            </svg>\
          </span>\
        </button>';
      mainBar.insertBefore(div1, mainBar.lastChild);
      $q("#reload-header-url").addEventListener("click", () => {alignToolbars()});
    }
  } catch(ex) {}
}

function reloadHeaderButtonToStatusbar() {
  let div2 = document.createElement("div"),
      statusBar = $q("footer > div.toolbar-statusbar");
  try {
    if (!$q(".reload-header-statusbar")) {
      div2.className = "button-toolbar reload-header-statusbar";
      div2.innerHTML = '\
        <button id="reload-header-statusbar" \
                class="ToolbarButton-Button custom-button" \
                title="Reload Header" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg viewBox="0 0 16 16" \
                 style="' + reloadHeaderButtonSmallIcon +'" >\
            </svg>\
          </span>\
        </button>';
      if ($q("#print-button")) statusBar.insertBefore(div2, statusBar.childNodes[3].nextSibling);
      else statusBar.insertBefore(div2, statusBar.childNodes[2].nextSibling);
      $q("#reload-header-statusbar").addEventListener("click", () => {alignToolbars()});
    }
  } catch(ex) {}
}

function onClose() {
  $q("#reload-header-url").removeEventListener("click", () => {alignToolbars()});
  $q("#reload-header-statusbar").removeEventListener("click", () => {alignToolbars()});
  $q("#print-button").removeEventListener("click", () => {printPage()});
  window.removeEventListener("drop", (e) => {e.preventDefault(); homeToRestartButton()});
  window.removeEventListener("resize", () => {setTimeout(() => {onResize()}, resizeDelay)});
}

function onResize() {
  if (!window.fullscreen) {
    alignToolbars();
    if (printPageButton) printButton();
    if (reloadHeaderButtonInUrlbar) reloadHeaderButtonToUrlbar();
    if (reloadHeaderButtonInStatusbar) reloadHeaderButtonToStatusbar();
    buttonPopupListener();
} }

window.addEventListener("drop", (e) => {e.preventDefault(); homeToRestartButton()});
window.addEventListener("load", () => {setTimeout(() => {alignToolbars()}, alignDelay)});
window.addEventListener("resize", () => {setTimeout(() => {onResize()}, resizeDelay)});
window.addEventListener("unload", () => {onClose()});