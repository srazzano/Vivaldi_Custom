// After any edits, initiate the vivaldi-custom.bat file to update Vivaldi Browser files.

(function() {

  "use strict";

  const 
  // toolbarAlignment options: .UrlBar, .bookmark-bar, .toolbar-statusbar
  // List in order from left (top position) to right (bottom position).
  // Comma separate entries and space after comma optional.
  // No entry for default position.
  // Use Toggle Tabbar button on statusbar to set Tabbar on Header bottom/top.
        toolbarAlignment = ".toolbar-statusbar, .bookmark-bar, .UrlBar",
  //
  // Increase time if toolbars require more time to properly load on browser start up.
        initializeDelay = 750,
  //
  // Allows tab time to aquire site favicon before sending to urlbar.
        favInterval = 750,
  //
  // Increase time for toolbars to properly load after exiting fullscreen mode.
        resizeDelay = 100,
  //
  // Background images, label text and tooltips.
        optionsIcon = "background: url(/style/options.png) center no-repeat",
        closeIcon = "background: url(/style/close.png) center no-repeat",
        reloadHeaderIcon = "background: url(/style/reload.png) center no-repeat",
        restartIcon = "background: url(/style/restart.png) center no-repeat",
        label1Text = "Button Popup",
        label2Text = "Close Button",
        label3Text = "Fav In Url",
        label4Text = "Folder Icon",
        label5Text = "Home Restart",
        label6Text = "Move Tab",
        label7Text = "Spinner Style",
        label8Text = "Tabs On Bottom",
        buttonPopupTooltip = "Custom arrow pointer popup box",
        closeButtonTooltip = "Larger tab close button",
        favInUrlTooltip = "Display site favicon in urlbar",
        customFolderTooltip = "Displays custom folder icon for bookmark folders",
        homeToRestartTooltip = "Display home button as restart button, see How-To.txt file",
        homeAsRestartTooltip = "Restart browser",
        customSpinnerTooltip = "Display custom spinner",
        tabsOnBottomTooltip = "Display tabbar on bottom of header",
        optionsCloseButtonTooltip = "Closes options menu",
        reloadHeaderTooltip = "Reload header back to user preferences",
        moveActiveTabTooltip = "Move clicked/active tab to first position",
  //
        list = toolbarAlignment.replace(/\s+/g, "")
                               .replace(".toolbar-statusbar", "footer")
                               .split(",");

  var favTimer,
      buttonPopup,
      closeButton,
      favInUrl,
      folderIcon,
      homeRestart,
      moveActiveTab,
      spinnerStyle,
      tabsOnBottom;

  function $c(type, attr, evls) {
    let node = document.createElement(type);
    if (attr && typeof attr === "object") {
      for (let prop in attr) {
        if (typeof node[prop] === "undefined") 
          node.setAttribute(prop, attr[prop]);
        else node[prop] = attr[prop];
    } }
    if (evls) for (let i = 0; i < evls.length; i++) {
      let evl = evls[i];
      node.addEventListener(evl.type, evl.fn);
    }
    return node;
  }

  function $i(newNode, refNode) {
    if (refNode.nextSibling) 
      return refNode.parentNode.insertBefore(newNode, refNode.nextSibling);
    return refNode.parentNode.appendChild(newNode);
  }

  function $q(el, all) {
    if (all) return document.querySelectorAll(el);
    return document.querySelector(el);
  }

  function initialize() {
    let browser = $q("#browser"),
        main = $q("#main"),
        tabs = $q(".tab-strip"),
        res = $q(".resize");
    try {
      if (toolbarAlignment) {
        for (let i = list.length - 1; i >= 0; i--)
          main.insertBefore($q(list[i]), main.firstChild);
      }
      chrome.storage.local.get(['buttonPopupKey'], result => {
        buttonPopup = result.buttonPopupKey;
        if (buttonPopup) {
          browser.setAttribute("custom-popup", true);
          customPopup(buttonPopup);
        } else browser.removeAttribute("custom-popup");
      });
      chrome.storage.local.get(['closeButtonKey'], result => {
        closeButton = result.closeButtonKey;
        if (closeButton) {
          browser.setAttribute("custom-close", true);
          customClose(closeButton);
        } else browser.removeAttribute("custom-close");
      });
      chrome.storage.local.get(['favInUrlKey'], result => {
        favInUrl = result.favInUrlKey;
        if (favInUrl) {
          browser.setAttribute("fav-in-url", true);
          favImage(favInUrl);
        } else browser.removeAttribute("fav-in-url");
      });
      chrome.storage.local.get(['folderIconKey'], result => {
        folderIcon = result.folderIconKey;
        if (folderIcon) {
          browser.setAttribute("custom-folder", true);
          customFolder(folderIcon);
        } else browser.removeAttribute("custom-folder");
      });
      chrome.storage.local.get(['homeRestartKey'], result => {
        homeRestart = result.homeRestartKey;
        if (homeRestart) homeToRestart(homeRestart);
      });
      chrome.storage.local.get(['moveActiveTabKey'], result => {
        moveActiveTab = result.moveActiveTabKey;
        if (moveActiveTab) moveTab(moveActiveTab);
      });
      chrome.storage.local.get(['spinnerStyleKey'], result => {
        spinnerStyle = result.spinnerStyleKey;
        if (spinnerStyle) {
          browser.setAttribute("custom-spinner", true);
          customSpinner(spinnerStyle);
        } else browser.removeAttribute("custom-spinner");
      });
      chrome.storage.local.get(['tabsOnBottomKey'], result => {
        tabsOnBottom = result.tabsOnBottomKey;
        if (tabsOnBottom) {
          browser.setAttribute("tabs-on-bottom", true);
          main.insertBefore(tabs, main.lastChild);
          tabbarToggle(tabsOnBottom);
        } else {
          browser.removeAttribute("tabs-on-bottom");
          res.appendChild(tabs);
        }
      });
      reloadHeader();
      optionsHolder();
    } catch(ex) {}
    buttonPopupListener();
  }

  function buttonPopupListener() {
    let statusBar = $q(".toolbar-statusbar");
    try {
      for (let i = 0; i < statusBar.childNodes.length; i++)
        statusBar.childNodes[i].onclick = () =>
          setTimeout(() => buttonPopupPosition(), 100);
    } catch(ex) {}
  }

  function buttonPopupPosition() {
    let main = $q("#main"),
        footer = $q("footer"),
        popup = $q(".button-popup"),
        footerHeight = footer.offsetHeight,
        footerTop = footer.offsetTop;
    try {
      if (main.nextSibling === footer) {
        popup.setAttribute("position", "bottom");
        popup.style.top = "auto";
        popup.style.bottom = (footerHeight + 6) + "px";
      } else {
        popup.setAttribute("position", "top");
        popup.style.bottom = "auto";
        if ($q(".topmenu")) 
          popup.style.top = (footerTop + footerHeight + 65) + "px";
        else {
          if (tabsOnBottom) popup.style.top = (footerHeight + 2) + "px";
          else popup.style.top = (footerTop + footerHeight + 33) + "px";
      } }
    } catch(ex) {}
  }

  function customClose(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-close", true);
      else browser.removeAttribute("custom-close");
    } catch(ex) {}
  }

  function customFolder(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-folder", true);
      else browser.removeAttribute("custom-folder");
    } catch(ex) {}
  }

  function customPopup(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-popup", true);
      else browser.removeAttribute("custom-popup");
    } catch(ex) {}
  }

  function customSpinner(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-spinner", true);
      else browser.removeAttribute("custom-spinner");
    } catch(ex) {}
  }

  function favImage(e) {
    let browser = $q("#browser"),
        field = $q(".UrlField"),
        img = $c("img", {id: "favImg"});
    try {
      if ($q("#favImg")) {
        field.removeChild(img);
        return;
      }
      if (e) {
        browser.setAttribute("fav-in-url", true);
        field.insertBefore(img, field.firstChild);
        getCurrentTabUpdated();
      } else browser.removeAttribute("fav-in-url");
    } catch(ex) {}
  }

  function getCurrentTab() {
    let field = $q(".UrlField"),
        img = $q("#favImg"),
        fav = $q(".favicon > img");
    try {
      if (!favInUrl) {
        field.removeChild(img);
        return;
      }
      chrome.tabs.query({currentWindow: true, active: true}, tabs => {
        if (tabs[0].title.match(/^Extensions$/))
          img.src = "/style/extensions.png";
        else if (tabs[0].title.match(/^Start Page$/))
          img.src = "/style/star.png";
        else if (tabs[0].title.match(/Settings$/))
          img.src = "/style/settings.png";
        else if (tabs[0].title.match(/^Installed Userscripts$/))
          img.src = "/style/tampermonkey.png";
        else if (tabs[0].title.match(/https:\/\/dmvapp/))
          img.src = "/style/dmv.png";
        else if (tabs[0].title.match(/YouTube TV$/))
          img.src = "/style/youtubetv.png";
        else if (tabs[0].url.match(/http:\/\/custombuttons/))
          img.src = "/style/custombuttons.png";
        else if (tabs[0].url.match(/https:\/\/www\.aarpmedicareplans/))
          img.src = "/style/united.png";
        else if (tabs[0].favIconUrl === "") 
          img.src = "/style/page.png";
        else 
          img.src = tabs[0].favIconUrl;
      });
    } catch(ex) {}
  }

  function getCurrentTabUpdated() {
    favTimer = setInterval(() => getCurrentTab(), favInterval);
  }

  function homeToRestart(e) {
    let homeBtn = $q("button[title='Go to homepage']"),
        homeBtnImg = $q("button[title='Go to homepage'] svg"),
        homeBtnPath = $q("button[title='Go to homepage'] svg > path"),
        homeBtn2 = $q("button[title='Restart browser']"),
        homeBtnImg2 = $q("button[title='Restart browser'] svg"),
        homeBtnPath2 = $q("button[title='Restart browser'] svg > path");
    try {
      if (e) {
        homeBtn.id = "restart-browser";
        homeBtn.className = "ToolbarButton-Button custom-button";
        homeBtn.title = homeAsRestartTooltip;
        homeBtnImg.style = restartIcon;
        homeBtnPath.style.display = "none";
      } else {
        homeBtn2.removeAttribute("id");
        homeBtn2.className = "ToolbarButton-Button";
        homeBtn2.title = "Go to homepage";
        homeBtnImg2.removeAttribute("style");
        homeBtnPath2.style.display = "block";
      }
    } catch(ex) {}
  }

  function moveTab(e) {
    let browser = $q("#browser");
    try {
      chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
      if (moveActiveTab) {
        browser.setAttribute("move-tab", true);
        chrome.tabs.query({currentWindow: true, active: true}, tabs =>
          chrome.tabs.move(tabs[0].id, {index: 0}));
      } else browser.removeAttribute("move-tab");
    } catch(ex) {}
  }

  function moveTabPosition(e) {
    if (!moveActiveTab) return;
    try {
      chrome.tabs.move(e.tabId, {index: 0});
    } catch (ex) {
      if (ex == "Error: Tabs can't be edited right now (may be dragging a tab).")
        setTimeout(() => moveTabPosition(e), 50);
  } }

  function optionsHolder() {
    let div0 = $c("div", {className: "button-toolbar options"}),
        statusBar = $q(".toolbar-statusbar");
    if ($q(".options")) return;
    try {
      div0.innerHTML = '\
        <button id="options-button" \
                class="ToolbarButton-Button custom-button" \
                title="Options Menu" \
                type="button" \
                tabindex="-1">\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 style="'+ optionsIcon +'"/>\
          </span>\
        </button>';
      chrome.storage.local.set({buttonPopupKey: buttonPopup});
      let divX = $c("div", {className: "button-toolbar options-menu"}),
          divY = $c("div"),
          input1 = $c("input", {id: "input1", className: "input", 
                   type: "checkbox", checked: buttonPopup}),
          label1 = $c("label", {id: "label1", className: "label", 
                   textContent: label1Text, title: buttonPopupTooltip}),
          input2 = $c("input", {id: "input2", className: "input", 
                   type: "checkbox", checked: closeButton}),
          label2 = $c("label", {id: "label2", className: "label", 
                   textContent: label2Text, title: closeButtonTooltip}),
          input3 = $c("input", {id: "input3", className: "input", 
                   type: "checkbox", checked: favInUrl}),
          label3 = $c("label", {id: "label3", className: "label", 
                   textContent: label3Text, title: favInUrlTooltip}),
          input4 = $c("input", {id: "input4", className: "input", 
                   type: "checkbox", checked: folderIcon}),
          label4 = $c("label", {id: "label4", className: "label", 
                   textContent: label4Text, title: customFolderTooltip}),
          input5 = $c("input", {id: "input5", className: "input", 
                   type: "checkbox", checked: homeRestart}),
          label5 = $c("label", {id: "label5", className: "label", 
                   textContent: label5Text, title: homeToRestartTooltip}),
          input6 = $c("input", {id: "input6", className: "input", 
                   type: "checkbox", checked: moveActiveTab}),
          label6 = $c("label", {id: "label6", className: "label", 
                   textContent: label6Text, title: moveActiveTabTooltip}),
          input7 = $c("input", {id: "input7", className: "input", 
                   type: "checkbox", checked: spinnerStyle}),
          label7 = $c("label", {id: "label7", className: "label", 
                   textContent: label7Text, title: customSpinnerTooltip}),
          input8 = $c("input", {id: "input8", className: "input", 
                   type: "checkbox", checked: tabsOnBottom}),
          label8 = $c("label", {id: "label8", className: "label", 
                   textContent: label8Text, title: tabsOnBottomTooltip}),
          button1 = $c("button", {className: "button", style: closeIcon, 
                    title: optionsCloseButtonTooltip}, [{type:"click", 
                    fn:()=> onOptions()}]);
      divY.appendChild(input1);
      divY.appendChild(label1);
      divY.appendChild(input2);
      divY.appendChild(label2);
      divY.appendChild(input3);
      divY.appendChild(label3);
      divY.appendChild(input4);
      divY.appendChild(label4);
      divY.appendChild(input5);
      divY.appendChild(label5);
      divY.appendChild(input6);
      divY.appendChild(label6);
      divY.appendChild(input7);
      divY.appendChild(label7);
      divY.appendChild(input8);
      divY.appendChild(label8);
      divY.appendChild(button1);
      divX.appendChild(divY);
      div0.appendChild(divX);
      $i(div0, statusBar.childNodes[2]);
      let num = $q(".options-menu .input", true);
      for (let i = 0; i < num.length; i++) 
        num[i].onclick = e => {onOptionsMenu(e.target.id)};
      $q("#options-button").onclick = function() {onOptions()};
    } catch(ex) {}
  }

  function onOptions() {
    let browser = $q("#browser");
    if (browser.hasAttribute("options")) browser.removeAttribute("options");
    else browser.setAttribute("options", true);
  }

  function onOptionsMenu(e) {
    let browser = $q("#browser"),
        el = document.getElementById(e);
    switch (e) {
      case "input1":
        buttonPopup = el.checked;
        chrome.storage.local.set({buttonPopupKey: buttonPopup});
        if (buttonPopup) {
          customPopup(buttonPopup);
          browser.setAttribute("custom-popup", true);
        } else browser.removeAttribute("custom-popup");
        break;
      case "input2":
        closeButton = el.checked;
        chrome.storage.local.set({closeButtonKey: closeButton});
        if (closeButton) {
          customClose(closeButton);
          browser.setAttribute("custom-close", true);
        } else browser.removeAttribute("custom-close");
        break;
      case "input3":
        favInUrl = el.checked;
        chrome.storage.local.set({favInUrlKey: favInUrl});
        if (favInUrl) {
          favImage(favInUrl);
          browser.setAttribute("fav-in-url", true);
        } else browser.removeAttribute("fav-in-url");
        break;
      case "input4":
        folderIcon = el.checked;
        chrome.storage.local.set({folderIconKey: folderIcon});
        if (folderIcon) {
          customFolder(folderIcon);
          browser.setAttribute("custom-folder", true);
        } else browser.removeAttribute("custom-folder");
        break;
      case "input5":
        homeRestart = el.checked;
        chrome.storage.local.set({homeRestartKey: homeRestart});
        homeToRestart(homeRestart);
       break;
      case "input6":
        moveActiveTab = el.checked;
        chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
        moveTab(moveActiveTab);
       break;
      case "input7":
        spinnerStyle = el.checked;
        chrome.storage.local.set({spinnerStyleKey: spinnerStyle});
        customSpinner(spinnerStyle);
        break;
      case "input8":
        tabsOnBottom = el.checked;
        chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
        tabbarToggle(tabsOnBottom);
  } }

  function reloadHeader() {
    let div1 = $c("div", {className: "button-toolbar reload-header"},
        [{type:"click", fn:()=> resetHeader()}]),
        mainBar = $q(".toolbar.toolbar-droptarget.toolbar-mainbar"),
        statusBar = $q(".toolbar-statusbar");
    if ($q(".reload-header")) return;
    try {
      div1.innerHTML = '\
        <button id="reload-header" \
                class="ToolbarButton-Button custom-button" \
                title="'+ reloadHeaderTooltip +'" \
                type="button" \
                tabindex="-1">\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 style="'+ reloadHeaderIcon +'"/>\
          </span>\
        </button>';
      mainBar.insertBefore(div1, mainBar.lastChild);
    } catch(ex) {}
  }

  function resetHeader() {
    let header = $q("#header"),
        main = $q("#main"),
        tabs = $q(".tab-strip"),
        footer = $q("footer");
    try {
      if (toolbarAlignment) {
        for (let i = list.length - 1; i >= 0; i--)
          main.insertBefore($q(list[i]), main.firstChild);
        if (tabsOnBottom) {
          main.insertBefore(tabs, main.lastChild);
          $i(footer, header.firstChild);
      } }
      homeToRestart(homeRestart);
      reloadHeader();
      optionsHolder();
    } catch(ex) {}
    buttonPopupListener();
  }

  function tabbarToggle(e) {
    let browser = $q("#browser"),
        header = $q("#header"),
        main = $q("#main"),
        res = $q(".resize"),
        tabs = $q(".tab-strip"),
        footer = $q("footer");
    try {
      chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
      if (e) {
        browser.setAttribute("tabs-on-bottom", true);
        main.insertBefore(tabs, main.lastChild);
        $i(footer, header.firstChild);
      } else {
        browser.removeAttribute("tabs-on-bottom");
        if (toolbarAlignment) {
          for (let i = list.length - 1; i >= 0; i--)
            main.insertBefore($q(list[i]), main.firstChild);
        }
        res.appendChild(tabs);
      }
    } catch(ex) {}
  }

  function onClose() {
    chrome.tabs.onActivated.removeListener(e => moveTabPosition(e));
    chrome.tabs.onHighlighted.removeListener((tabId, changeInfo, tab) =>
      getCurrentTab());
    chrome.tabs.onUpdated.removeListener((tabId, changeInfo, tab) => {
      if (tab.status === "complete") {
        getCurrentTabUpdated();
        clearInterval(favTimer);
      }
    });
  }

  function onResize() {
    if (!window.fullscreen) resetHeader();
  }

  chrome.storage.local.get(['buttonPopupKey'], result => {
    buttonPopup = result.buttonPopupKey;
    customPopup(buttonPopup);
  });

  chrome.storage.local.get(['closeButtonKey'], result => {
    closeButton = result.closeButtonKey;
    customClose(closeButton);
  });

  chrome.storage.local.get(['favInUrlKey'], result => {
    favInUrl = result.favInUrlKey;
    favImage(favInUrl);
  });

  chrome.storage.local.get(['folderIconKey'], result => {
    folderIcon = result.folderIconKey;
    customFolder(folderIcon);
  });

  chrome.storage.local.get(['homeRestartKey'], result => {
    homeRestart = result.homeRestartKey;
    homeToRestart(homeRestart);
  });

  chrome.storage.local.get(['moveActiveTabKey'], result => {
    moveActiveTab = result.moveActiveTabKey;
    moveTab(moveActiveTab);
  });

  chrome.storage.local.get(['spinnerStyleKey'], result => {
    spinnerStyle = result.spinnerStyleKey;
    customSpinner(spinnerStyle);
  });

  chrome.storage.local.get(['tabsOnBottomKey'], result => {
    tabsOnBottom = result.tabsOnBottomKey;
  });

  chrome.tabs.onActivated.addListener(e => moveTabPosition(e));

  chrome.tabs.onHighlighted.addListener((tabId, changeInfo, tab) =>
    getCurrentTab());

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.status === "complete") {
      getCurrentTabUpdated();
      clearInterval(favTimer);
    }
  });

  window.onload = () => setTimeout(() => {
    chrome.storage.local.get(['moveActiveTabKey'], result => {
      moveActiveTab = result.moveActiveTabKey;
      moveTab(moveActiveTab);
    });
    chrome.storage.local.get(['tabsOnBottomKey'], result => {
      tabsOnBottom = result.tabsOnBottomKey;
      tabbarToggle(tabsOnBottom);
    });
    initialize()}, initializeDelay);

  window.onresize = () => setTimeout(() => onResize(), resizeDelay);

  window.ondrop = e => {
    e.preventDefault();
    homeToRestart(homeRestart);
  };

  window.onunload = () => {
    chrome.storage.local.set({buttonPopupKey: buttonPopup});
    chrome.storage.local.set({closeButtonKey: closeButton});
    chrome.storage.local.set({favInUrlKey: favInUrl});
    chrome.storage.local.set({folderIconKey: folderIcon});
    chrome.storage.local.set({homeRestartKey: homeRestart});
    chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
    chrome.storage.local.set({spinnerStyleKey: spinnerStyle});
    chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
    onClose();
  };

})();
