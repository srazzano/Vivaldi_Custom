/* use strict */

const 
      toolbarAlignment = "footer, .UrlBar, .bookmark-bar",
// Options: .UrlBar, .toolbar-extensions, .bookmark-bar, footer
// List in order from left (top position) to right (bottom position).
// Comma separate entries and space after comma optional.
// No entry for default position.
//
      initializeDelay = 500,
// Increase time if toolbars require more time to properly load on browser start up.
//
      favInterval = 1000,
//
      resizeDelay = 100,
// Increase time if toolbars require more time to properly load after exiting fullscreen mode.
//
      customSpinnerStyle = 1,
// 1, 2 or 3 displays different custom spinners. 0 or any other integer displays default spinner.
//
      customButtonPopup = true,
// Displays a custom button popup with arrow.
//
      customCloseButton = true,
// Displays a larger custom tab close button.
//
      customFolderIcon = true,
// Displays a custom bookmark folder icon for folders.
//
      favInUrlbar = true,
// Displays site favicons in urlbar.
//
      homeAsRestart = true,
// If true, sets Home button as Restart Browser function, with 16px icon and tooltip. 
// Requires following steps: Open Settings > General > STARTUP section, select 
// Homepage Specific Page radio and enter vivaldi://restart into input textbox.
//
      reloadHeaderIcon = "background: url(/style/reload.png) center no-repeat",
      restartIcon = "background: url(/style/restart.png) center no-repeat",
      toggleIcon = "background: url(/style/toggle.png) center no-repeat",
      tabMoveTooltip = "Move Clicked/Active Tab Activated: ",
      tabbarToggleTooltip = "Toggle Tabbar Bottom/Top";

var favTimer,
    moveTabOnClick,
    tabsOnBottom;

function $c(type, attr) {
  let node = document.createElement(type);
  for (let prop in attr) node.setAttribute(prop, attr[prop]);
  return node;
}

function $i(newNode, refNode) {
  if (refNode.nextSibling) 
    return refNode.parentNode.insertBefore(newNode, refNode.nextSibling);
  return refNode.parentNode.appendChild(newNode);
}

function $q(el, all) {
  if (all) return document.querySelectorAll(el);
  return document.querySelector(el);
}

function initialize() {
  window.removeEventListener("load", () => {setTimeout(() => {
    chrome.storage.local.get(['moveTabKey'], function(result) {
      moveTabOnClick = result.moveTabKey;
      tabMoveOption();
    });
    initialize()}, initializeDelay);
  });
  let browser = $q("#browser"),
      main = $q("#main"),
      tabs = $q(".tab-strip"),
      res = $q(".resize"),
      list = toolbarAlignment.replace(/\s+/g, "").split(",");
  try {
    if (toolbarAlignment) for (let i = list.length - 1; i >= 0; i--) 
      main.insertBefore($q(list[i]), main.firstChild);
    if (main.lastChild.previousSibling.previousSibling === tabs) 
      browser.setAttribute("tabs-on-bottom", true);
    else browser.removeAttribute("tabs-on-bottom");
    if (tabsOnBottom) main.insertBefore(tabs, main.lastChild);
    else res.appendChild(tabs);
    customClose(customCloseButton);
    customFolder(customFolderIcon);
    customPopup(customButtonPopup);
    customSpinner(customSpinnerStyle);
    favImageHolder(favInUrlbar);
    homeToRestart(homeAsRestart);
    reloadHeader();
    tabMoveHolder();
    tabbarToggleHolder();
  } catch(ex) {}
  buttonPopupListener();
}

function init2() {
  let main = $q("#main"),
      list = toolbarAlignment.replace(/\s+/g, "").split(",");
  try {
    if (toolbarAlignment) for (let i = list.length - 1; i >= 0; i--) 
      main.insertBefore($q(list[i]), main.firstChild);
    homeToRestart(homeAsRestart);
    tabMoveHolder();
    tabbarToggleHolder();
    reloadHeader();
  } catch(ex) {}
  buttonPopupListener();
}

function buttonPopupListener() {
  let statusBar = $q(".toolbar-statusbar");
  try {
    for (let i = 0; i < statusBar.childNodes.length; i++)
      statusBar.childNodes[i].addEventListener("click", () => {buttonPopupPosition()});
  } catch(ex) {}
}

function buttonPopupPosition() {
  let main = $q("#main"),
      footer = $q("footer"),
      popup = $q(".button-popup"),
      footerHeight = footer.offsetHeight,
      footerTop = footer.offsetTop;
  try {
    if (main.nextSibling === footer) {
      popup.setAttribute("position", "bottom");
      popup.style.top = "auto";
      popup.style.bottom = (footerHeight + 6) + "px";
    } else {
      popup.setAttribute("position", "top");
      popup.style.bottom = "auto";
      if ($q(".topmenu")) popup.style.top = (footerTop + footerHeight + 65) + "px";
      else popup.style.top = (footerTop + footerHeight + 36) + "px";
    }
  } catch(ex) {}
}

function customClose(e) {
  let browser = $q("#browser");
  if (e) browser.setAttribute("custom-close", true);
  else browser.removeAttribute("custom-close");
}

function customFolder(e) {
  let browser = $q("#browser");
  if (e) browser.setAttribute("custom-folder", true);
  else browser.removeAttribute("custom-folder");
}

function customPopup(e) {
  let browser = $q("#browser");
  if (e) browser.setAttribute("custom-popup", true);
  else browser.removeAttribute("custom-popup");
}

function customSpinner(e) {
  let browser = $q("#browser");
  if (e === 1 || e === 2 || e === 3) browser.setAttribute("custom-spinner", e);
  else browser.removeAttribute("custom-spinner");
}

function favImageHolder(e) {
  if ($q("#favImg")) return;
  if (e) {
    let browser = $q("#browser"),
        field = $q(".UrlField"),
        img = $c("img", {id: "favImg"});
    browser.setAttribute("fav-in-url", true);
    field.insertBefore(img, field.firstChild);
    getCurrentTabUpdated();
  } else browser.removeAttribute("fav-in-url");
}

function getCurrentTab() {
  if (!favInUrlbar) return;
  let img = $q("#favImg");
  try {
    chrome.tabs.query({currentWindow: true, active: true}, tabs => {
      if (tabs[0].title.match(/^Extensions$/)) img.src = "/style/extensions.png";
      else if (tabs[0].title.match(/Settings$/)) img.src = "/style/settings.png";
      else if (tabs[0].url.match(/http:\/\/custombuttons/)) img.src = "/style/custombuttons.png";
      else if (tabs[0].favIconUrl === "") img.src = "/style/default.png";
      else img.src = tabs[0].favIconUrl;
    });
  } catch(ex) {}
}

function getCurrentTabUpdated() {
  favTimer = setInterval(() => {getCurrentTab()}, favInterval);
}

function homeToRestart(e) {
  if (!e) return;
  let homeBtn = $q("button[title='Go to homepage']"),
      homeBtnImg = $q("button[title='Go to homepage'] svg"),
      homeBtnPath = $q("button[title='Go to homepage'] svg > path");
  homeBtn.id = "restart-browser";
  homeBtn.className = "ToolbarButton-Button custom-button";
  homeBtn.title = "Restart Browser";
  homeBtnImg.style = restartIcon;
  homeBtnPath.style.display = "none";
}

function reloadHeader() {
  let div1 = $c("div", {class: "button-toolbar reload-header"}),
      mainBar = $q(".toolbar.toolbar-droptarget.toolbar-mainbar");
  try {
    if (!$q(".reload-header")) {
      div1.innerHTML = '\
        <button id="reload-header" \
                class="ToolbarButton-Button custom-button" \
                title="Reload Header" \
                style="border-radius: 50%" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 viewBox="0 0 26 26" \
                 style="'+ reloadHeaderIcon +'"/>\
          </span>\
        </button>';
      mainBar.insertBefore(div1, mainBar.lastChild);
      $q("#reload-header").addEventListener("click", () => {initialize()});
    }
  } catch(ex) {}
}

function tabMoveHolder() {
  let div3 = $c("div", {class: "button-toolbar move-tab"}),
      statusBar = $q(".toolbar-statusbar"),
      bool = moveTabOnClick.toString().toUpperCase();
  try {
    if (!$q(".move-tab")) {
      div3.innerHTML = '\
        <button id="move-tab-button" \
                class="ToolbarButton-Button custom-button" \
                title="'+ tabMoveTooltip + bool +'" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 viewBox="0 0 16 16"/>\
          </span>\
        </button>';
      $i(div3, statusBar.childNodes[2]);
      $q(".move-tab").addEventListener("click", () => {
        moveTabOnClick = !moveTabOnClick;
        tabMoveOption();
      });
    }
  } catch(ex) {}
}

function tabMoveOption() {
  let browser = $q("#browser"),
      btn = $q("#move-tab-button"),
      bool = moveTabOnClick.toString().toUpperCase();
  try {
    chrome.storage.local.set({moveTabKey: moveTabOnClick});
    if (moveTabOnClick) {
      browser.setAttribute("move-tab", true);
      chrome.tabs.query({currentWindow: true, active: true}, tabs => {
        chrome.tabs.move(tabs[0].id, {index: 0});
      });
    } else browser.removeAttribute("move-tab");
    btn.title = tabMoveTooltip + bool;
  } catch(ex) {}
}

function tabMovePosition(e) {
  if (!moveTabOnClick) return;
  try {
    chrome.tabs.move(e.tabId, {index: 0});
  } catch (ex) {
    if (ex == "Error: Tabs can't be edited right now (may be dragging a tab).") {
      setTimeout(() => {tabMovePosition(e)}, 50);
} } }

function tabbarToggleHolder() {
  let div4 = $c("div", {class: "button-toolbar tabs-on-bottom"}),
      statusBar = $q(".toolbar-statusbar");
  try {
    if (!$q(".tabs-on-bottom")) {
      div4.innerHTML = '\
        <button id="tabs-on-bottom-button" \
                class="ToolbarButton-Button custom-button" \
                title="'+ tabbarToggleTooltip +'" \
                type="button" \
                tabindex="-1" >\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 viewBox="0 0 16 16" \
                 style="'+ toggleIcon +'"/>\
          </span>\
        </button>';
      $i(div4, statusBar.childNodes[3]);
      $q(".tabs-on-bottom").addEventListener("click", () => {
        tabsOnBottom = !tabsOnBottom;
        tabbarTogglePosition();
      });
    }
  } catch(ex) {}
}

function tabbarTogglePosition() {
  let browser = $q("#browser"),
      main = $q("#main"),
      res = $q(".resize"),
      tabs = $q(".tab-strip");
  try {
    chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
    if (tabsOnBottom) browser.setAttribute("tabs-on-bottom", true);
    else browser.removeAttribute("tabs-on-bottom");
    if (tabsOnBottom) main.insertBefore(tabs, main.lastChild);
    else res.appendChild(tabs);
  } catch(ex) {}
}

function onClose() {
  chrome.tabs.onActivated.removeListener(e => {
    tabMovePosition(e);
  });
  chrome.tabs.onHighlighted.removeListener((tabId, changeInfo, tab) => {
    getCurrentTab();
  });
  chrome.tabs.onUpdated.removeListener((tabId, changeInfo, tab) => {
    if (tab.status === "complete") {
      getCurrentTabUpdated();
      clearInterval(favTimer);
    }
  });
  for (let i = 0; i < statusBar.childNodes.length; i++)
    statusBar.childNodes[i].removeEventListener("click", () => {buttonPopupPosition()});
  $q(".move-tab").removeEventListener("click", () => {
    moveTabOnClick = !moveTabOnClick;
    tabMoveOption();
  });
  $q(".tabs-on-bottom").removeEventListener("click", () => {
    tabsOnBottom = !tabsOnBottom;
    tabbarTogglePosition();
  });
  $q("#reload-header-url").removeEventListener("click", () => {initialize()});
  window.removeEventListener("drop", e => {
    e.preventDefault();
    initialize();
  });
  window.removeEventListener("resize", () => {
    setTimeout(() => {onResize()}, resizeDelay);
  });
  window.removeEventListener("beforeunload", () => {
    chrome.storage.local.set({moveTabKey: moveTabOnClick}); onClose();
  });
  window.removeEventListener("unload", () => {
    chrome.storage.local.set({moveTabKey: moveTabOnClick}); onClose();
  });
}

function onResize() {
  if (!window.fullscreen) init2();
}

chrome.storage.local.get(['moveTabKey'], function(result) {
  moveTabOnClick = result.moveTabKey; tabMoveOption();
});
chrome.storage.local.get(['tabsOnBottomKey'], function(result) {
  tabsOnBottom = result.tabsOnBottomKey;
});
chrome.tabs.onActivated.addListener(e => {
  tabMovePosition(e);
});
chrome.tabs.onHighlighted.addListener((tabId, changeInfo, tab) => {
  getCurrentTab();
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.status === "complete") {
    getCurrentTabUpdated();
    clearInterval(favTimer);
  }
});
window.addEventListener("load", () => {setTimeout(() => {
  chrome.storage.local.get(['moveTabKey'], function(result) {
    moveTabOnClick = result.moveTabKey;
    tabMoveOption();
  });
  initialize()}, initializeDelay);
});
window.addEventListener("drop", e => {
  e.preventDefault();
  initialize();
});
window.addEventListener("resize", () => {
  setTimeout(() => {onResize()}, resizeDelay);
});
window.addEventListener("beforeunload", () => {
  chrome.storage.local.set({moveTabKey: moveTabOnClick}); onClose();
});
window.addEventListener("unload", () => {
  chrome.storage.local.set({moveTabKey: moveTabOnClick}); onClose();
});
