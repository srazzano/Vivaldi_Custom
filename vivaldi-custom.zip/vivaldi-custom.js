// After any edits, initiate the vivaldi-custom.bat file to update Vivaldi Browser files.

(function() {

  "use strict";

  const 
  // Increase time if toolbars require more time to properly load on browser start up.
        initializeDelay = 750,
  //
  // Allows tab time to aquire site favicon before sending to urlbar.
        favInterval = 750,
  //
  // Increase time for toolbars to properly load after exiting fullscreen mode.
        resizeDelay = 100,
  //
  // Background images, label text and tooltips.
        closeIcon = "background: url(/style/close.png) center no-repeat",
        optionsIcon = "background: url(/style/options.png) center no-repeat",
        reloadHeaderIcon = "background: url(/style/reload.png) center no-repeat",
        restartIcon = "background: url(/style/restart.png) center no-repeat",
        spinner1Icon = "background: url(/style/spinner1.png) center no-repeat !important;",
        spinner2Icon = "background: url(/style/spinner2.gif) center no-repeat !important;",
        spinner3Icon = "background: url(/style/spinner3.gif) center no-repeat !important;",
        label1Text = "Button Popup Arrow Box",
        label2Text = "Large Tab Close Button",
        label3Text = "Site Favicon In Urlbar",
        label4Text = "Custom Bookmark Folder Icon",
        label5Text = "Home Button to Restart Button",
        label6Text = "Move Tab To First Position",
        label7Text = "Tabbar On Bottom In Header",
        label8Text = "Custom Tab Spinner (1 - 3)",
        buttonPopupTooltip = "Button popup box with arrow pointer",
        closeButtonTooltip = "Displays larger tab close button",
        customFolderTooltip = "Displays custom folder icon for bookmark folders",
        customSpinnerTooltip = "Display 1 of 3 custom tab spinners",
        favInUrlTooltip = "Display site favicon in urlbar",
        homeAsRestartTooltip = "Restart browser",
        homeToRestartTooltip = "Display home button as restart button.\nIn Settings > General > Homepage >\nSpecific Page > enter vivaldi://restart",
        moveActiveTabTooltip = "Move clicked/active tab to first position",
        optionsCloseTooltip = "Closes options menu",
        optionsMenuTooltip = "Options Menu",
        reloadHeaderTooltip = "Reload header back to user preferences",
        tabsOnBottomTooltip = "Position tabbar on bottom in header.\nFooter moves to top position.",
        toolbarListTooltip = "Moveable Toolbars: footer, .bookmark-bar, .UrlBar";

  var buttonPopup,
      closeButton,
      favInUrl,
      favTimer,
      folderIcon,
      homeRestart,
      list,
      moveActiveTab,
      spinnerStyle,
      tabsOnBottom,
      toolbarList;

  function $c(type, attr, evls) {
    let node = document.createElement(type);
    if (attr && typeof attr === "object") {
      for (let prop in attr) {
        if (typeof node[prop] === "undefined") 
          node.setAttribute(prop, attr[prop]);
        else node[prop] = attr[prop];
    } }
    if (evls) for (let i = 0; i < evls.length; i++) {
      let evl = evls[i];
      node.addEventListener(evl.type, evl.fn);
    }
    return node;
  }

  function $i(newNode, refNode) {
    if (refNode.nextSibling) 
      return refNode.parentNode.insertBefore(newNode, refNode.nextSibling);
    return refNode.parentNode.appendChild(newNode);
  }

  function $q(el, all) {
    if (all) return document.querySelectorAll(el);
    return document.querySelector(el);
  }

  function initialize() {
    let browser = $q("#browser"),
        main = $q("#main"),
        tabs = $q(".tab-strip"),
        res = $q(".resize");
    try {
      chrome.storage.local.get(['buttonPopupKey'], result => {
        buttonPopup = result.buttonPopupKey;
        if (buttonPopup) {
          browser.setAttribute("custom-popup", true);
          customPopup(buttonPopup);
        } else browser.removeAttribute("custom-popup");
      });
      chrome.storage.local.get(['closeButtonKey'], result => {
        closeButton = result.closeButtonKey;
        if (closeButton) {
          browser.setAttribute("custom-close", true);
          customClose(closeButton);
        } else browser.removeAttribute("custom-close");
      });
      chrome.storage.local.get(['favInUrlKey'], result => {
        favInUrl = result.favInUrlKey;
        if (favInUrl) {
          browser.setAttribute("fav-in-url", true);
          favImage(favInUrl);
        } else browser.removeAttribute("fav-in-url");
      });
      chrome.storage.local.get(['folderIconKey'], result => {
        folderIcon = result.folderIconKey;
        if (folderIcon) {
          browser.setAttribute("custom-folder", true);
          customFolder(folderIcon);
        } else browser.removeAttribute("custom-folder");
      });
      chrome.storage.local.get(['homeRestartKey'], result => {
        homeRestart = result.homeRestartKey;
        if (homeRestart) homeToRestart(homeRestart);
      });
      chrome.storage.local.get(['moveActiveTabKey'], result => {
        moveActiveTab = result.moveActiveTabKey;
        if (moveActiveTab) moveTab(moveActiveTab);
      });
      chrome.storage.local.get(['spinnerStyleKey'], result => {
        spinnerStyle = result.spinnerStyleKey;
        if (spinnerStyle) {
          browser.setAttribute("custom-spinner", spinnerStyle);
          customSpinner(spinnerStyle);
        } else browser.removeAttribute("custom-spinner");
      });
      chrome.storage.local.get(['tabsOnBottomKey'], result => {
        tabsOnBottom = result.tabsOnBottomKey;
        if (tabsOnBottom) {
          browser.setAttribute("tabs-on-bottom", true);
          main.insertBefore(tabs, main.lastChild);
          tabbarToggle(tabsOnBottom);
        } else {
          browser.removeAttribute("tabs-on-bottom");
          res.appendChild(tabs);
        }
      });
      chrome.storage.local.get(['toolbarListKey'], result => {
        toolbarList = result.toolbarListKey;
        if (toolbarList) getToolbarList(toolbarList);
      });
      reloadHeader();
      optionsMenu();
    } catch(ex) {}
    buttonPopupListener();
  }

  function buttonPopupListener() {
    let statusBar = $q(".toolbar-statusbar");
    try {
      for (let i = 0; i < statusBar.childNodes.length; i++)
        statusBar.childNodes[i].onclick = () =>
          setTimeout(() => buttonPopupPosition(), 100);
    } catch(ex) {}
  }

  function buttonPopupPosition() {
    let main = $q("#main"),
        footer = $q("footer"),
        popup = $q(".button-popup"),
        footerHeight = footer.offsetHeight,
        footerTop = footer.offsetTop;
    try {
      if (main.nextSibling === footer) {
        popup.setAttribute("position", "bottom");
        popup.style.top = "auto";
        popup.style.bottom = (footerHeight + 6) + "px";
      } else {
        popup.setAttribute("position", "top");
        popup.style.bottom = "auto";
        if ($q(".topmenu")) 
          popup.style.top = (footerTop + footerHeight + 65) + "px";
        else {
          if (tabsOnBottom) popup.style.top = (footerHeight + 2) + "px";
          else popup.style.top = (footerTop + footerHeight + 33) + "px";
      } }
    } catch(ex) {}
  }

  function customClose(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-close", true);
      else browser.removeAttribute("custom-close");
    } catch(ex) {}
  }

  function customFolder(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-folder", true);
      else browser.removeAttribute("custom-folder");
    } catch(ex) {}
  }

  function customPopup(e) {
    let browser = $q("#browser");
    try {
      if (e) browser.setAttribute("custom-popup", true);
      else browser.removeAttribute("custom-popup");
    } catch(ex) {}
  }

  function customSpinner(e) {
    let browser = $q("#browser");
    try {
      if (e > 0 && e < 4) browser.setAttribute("custom-spinner", e);
      else browser.removeAttribute("custom-spinner");
    } catch(ex) {}
  }

  function favImage(e) {
    let browser = $q("#browser"),
        field = $q(".UrlField"),
        img = $c("img", {id: "favImg"});
    try {
      if ($q("#favImg")) {
        field.removeChild(img);
        return;
      }
      if (e) {
        browser.setAttribute("fav-in-url", true);
        field.insertBefore(img, field.firstChild);
        getCurrentTabUpdated();
      } else browser.removeAttribute("fav-in-url");
    } catch(ex) {}
  }

  function getCurrentTab() {
    let field = $q(".UrlField"),
        img = $q("#favImg");
    try {
      if (!favInUrl) {
        field.removeChild(img);
        return;
      }
      chrome.tabs.query({currentWindow: true, active: true}, tabs => {
        if (tabs[0].title.match(/^Extensions$/))
          img.src = "/style/extensions.png";
        else if (tabs[0].title.match(/^Start Page$/))
          img.src = "/style/star.png";
        else if (tabs[0].title.match(/Settings$/))
          img.src = "/style/settings.png";
        else if (tabs[0].title.match(/^Installed Userscripts$/))
          img.src = "/style/tampermonkey.png";
        else if (tabs[0].title.match(/https:\/\/dmvapp/))
          img.src = "/style/dmv.png";
        else if (tabs[0].title.match(/YouTube TV$/))
          img.src = "/style/youtubetv.png";
        else if (tabs[0].url.match(/http:\/\/custombuttons/))
          img.src = "/style/custombuttons.png";
        else if (tabs[0].url.match(/https:\/\/www\.aarpmedicareplans/))
          img.src = "/style/united.png";
        else if (tabs[0].favIconUrl === "") 
          img.src = "/style/page.png";
        else 
          img.src = tabs[0].favIconUrl;
      });
    } catch(ex) {}
  }

  function getCurrentTabUpdated() {
    favTimer = setInterval(() => getCurrentTab(), favInterval);
  }

  function getToolbarList(e) {
    e = e.replace(/\s+/g, "")
         .replace(/^,|,$/, "")
         .split(",");
    for (let i = e.length - 1; i >= 0; i--) 
      main.insertBefore($q(e[i]), main.firstChild);
    resetHeader();
  }

  function homeToRestart(e) {
    let homeBtn = $q("button[title='Go to homepage']"),
        homeBtnImg = $q("button[title='Go to homepage'] svg"),
        homeBtnPath = $q("button[title='Go to homepage'] svg > path"),
        homeBtn2 = $q("button[title='Restart browser']"),
        homeBtnImg2 = $q("button[title='Restart browser'] svg"),
        homeBtnPath2 = $q("button[title='Restart browser'] svg > path");
    try {
      if (e) {
        homeBtn.id = "restart-browser";
        homeBtn.className = "ToolbarButton-Button custom-button";
        homeBtn.title = homeAsRestartTooltip;
        homeBtnImg.style = restartIcon;
        homeBtnPath.style.display = "none";
      } else {
        homeBtn2.removeAttribute("id");
        homeBtn2.className = "ToolbarButton-Button";
        homeBtn2.title = "Go to homepage";
        homeBtnImg2.removeAttribute("style");
        homeBtnPath2.style.display = "block";
      }
    } catch(ex) {}
  }

  function moveTab(e) {
    let browser = $q("#browser");
    try {
      chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
      if (moveActiveTab) {
        browser.setAttribute("move-tab", true);
        chrome.tabs.query({currentWindow: true, active: true}, tabs =>
          chrome.tabs.move(tabs[0].id, {index: 0}));
      } else browser.removeAttribute("move-tab");
    } catch(ex) {}
  }

  function moveTabPosition(e) {
    if (!moveActiveTab) return;
    try {
      chrome.tabs.move(e.tabId, {index: 0});
    } catch (ex) {
      if (ex == "Error: Tabs can't be edited right now.")
        setTimeout(() => moveTabPosition(e), 50);
  } }

  function optionsMenu() {
    let divX = $c("div", {id: "options", className: "button-toolbar"}),
        divY = $c("div", {id: "options-menu", className: "options-menu"}),
        browser = $q("#browser"),
        statusBar = $q(".toolbar-statusbar");
    if ($q("#options-button")) return;
    try {
      divX.innerHTML = '\
        <button id="options-button"\
                class="ToolbarButton-Button custom-button"\
                title="'+ optionsMenuTooltip +'"\
                type="button"\
                tabindex="-1">\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 height="16" width="16"\
                 style="'+ optionsIcon +'"/>\
          </span>\
        </button>\
      </div>';
      divY.innerHTML = '\
        <div>\
          <span>Options Menu</span>\
          <span>\
            <button id="options-menu-button"\
                    class="button"\
                    style="'+ closeIcon +'"\
                    title="'+ optionsCloseTooltip +'"/>\
          </span>\
        </div>\
        <label>\
          <input id="input1"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span1"\
                class="span"\
                title="' + buttonPopupTooltip +'">'+ label1Text +'</span>\
        </label>\
        <label>\
          <input id="input2"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span2"\
                class="span"\
                title="' + closeButtonTooltip +'">'+ label2Text +'</span>\
        </label>\
        <label>\
          <input id="input3"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span3"\
                class="span"\
                title="'+ favInUrlTooltip +'">'+ label3Text +'</span>\
        </label>\
        <label>\
          <input id="input4"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span4"\
                class="span"\
                title="' + customFolderTooltip +'">'+ label4Text +'</span>\
        </label>\
        <label>\
          <input id="input5"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span5"\
                class="span"\
                title="' + homeToRestartTooltip +'">'+ label5Text +'</span>\
        </label>\
        <label>\
          <input id="input6"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span6"\
                class="span"\
                title="' + moveActiveTabTooltip +'">'+ label6Text +'</span>\
        </label>\
        <label>\
          <input id="input7"\
                 class="input"\
                 type="checkbox"/>\
          <span id="span7"\
                class="span"\
                title="' + tabsOnBottomTooltip +'">'+ label7Text +'</span>\
        </label>\
        <label>\
          <input id="input8"\
                 class="input"\
                 type="number"\
                 value="1"></input>\
          <span id="span8"\
                class="span"\
                title="' + customSpinnerTooltip +'">'+ label8Text +'</span>\
           <span class="image">\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 height="16" width="16"\
                 style="'+ spinner1Icon +'"/>\
          </span>\
          <span class="image">\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 height="16" width="16"\
                 style="'+ spinner2Icon +'"/>\
          </span>\
          <span class="image">\
            <svg xmlns="http://www.w3.org/2000/svg"\
                 height="16" width="16"\
                 style="'+ spinner3Icon +'"/>\
          </span>\
        </label>\
        <span>\
          <input id="input9"\
                 class="input"\
                 type="text"\
                 value="footer, .bookmark-bar, .UrlBar"\
                 spellcheck="false"\
                 title="'+ toolbarListTooltip +'"/>\
       </span>\
      </div>';
      $i(divX, statusBar.childNodes[2]);
      $i(divY, browser.lastChild);
      $q("div#options-menu > label > #input1").checked = buttonPopup;
      $q("div#options-menu > label > #input2").checked = closeButton;
      $q("div#options-menu > label > #input3").checked = favInUrl;
      $q("div#options-menu > label > #input4").checked = folderIcon;
      $q("div#options-menu > label > #input5").checked = homeRestart;
      $q("div#options-menu > label > #input6").checked = moveActiveTab;
      $q("div#options-menu > label > #input7").checked = tabsOnBottom;
      $q("div#options-menu > label > #input8").value = spinnerStyle;
      $q("div#options-menu > span > #input9").value = toolbarList;
      let ip = $q("#options-menu > label > [type='checkbox']", true);
      for (let i = 0; i < ip.length; i++) 
        ip[i].onclick = e => onOptionsMenu(e.target.id);
      $q("#input8").oninput = e => onOptionsMenu(e.target.id);
      $q("#input9").onchange = e => onOptionsMenu(e.target.id);
      $q("#options-button").onclick = () => onOptions();
      $q("#options-menu-button").onclick = () => onOptions();
    } catch(ex) {}
  }

  function onOptions() {
    let browser = $q("#browser"),
        inner = $q("#main > .inner"),
        menu = $q("#options-menu"),
        winHeight = window.screen.height;
    if (browser.hasAttribute("options")) browser.removeAttribute("options");
    else browser.setAttribute("options", true);
    menu.style.top = (winHeight - inner.offsetHeight) + "px";
    removeDupes("options-menu");
    toolbarList = $q("#input9").value.replace(/\s+/g, "")
                               .replace(/^,|,$/, "");
    chrome.storage.local.set({toolbarListKey: toolbarList});
    getToolbarList(toolbarList);
  }

  function onOptionsMenu(e) {
    let browser = $q("#browser"),
        el = document.getElementById(e);
    switch (e) {
      case "input1":
        buttonPopup = el.checked;
        chrome.storage.local.set({buttonPopupKey: buttonPopup});
        if (buttonPopup) {
          customPopup(buttonPopup);
          browser.setAttribute("custom-popup", true);
        } else browser.removeAttribute("custom-popup");
        break;
      case "input2":
        closeButton = el.checked;
        chrome.storage.local.set({closeButtonKey: closeButton});
        if (closeButton) {
          customClose(closeButton);
          browser.setAttribute("custom-close", true);
        } else browser.removeAttribute("custom-close");
        break;
      case "input3":
        favInUrl = el.checked;
        chrome.storage.local.set({favInUrlKey: favInUrl});
        if (favInUrl) {
          favImage(favInUrl);
          browser.setAttribute("fav-in-url", true);
        } else browser.removeAttribute("fav-in-url");
        break;
      case "input4":
        folderIcon = el.checked;
        chrome.storage.local.set({folderIconKey: folderIcon});
        if (folderIcon) {
          customFolder(folderIcon);
          browser.setAttribute("custom-folder", true);
        } else browser.removeAttribute("custom-folder");
        break;
      case "input5":
        homeRestart = el.checked;
        chrome.storage.local.set({homeRestartKey: homeRestart});
        homeToRestart(homeRestart);
       break;
      case "input6":
        moveActiveTab = el.checked;
        chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
        moveTab(moveActiveTab);
       break;
      case "input7":
        tabsOnBottom = el.checked;
        chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
        tabbarToggle(tabsOnBottom);
        break;
      case "input8":
        spinnerStyle = el.value;
        chrome.storage.local.set({spinnerStyleKey: spinnerStyle});
        customSpinner(spinnerStyle);
        break;
      case "input9":
        toolbarList = el.value.replace(/\s+/g, "")
                              .replace(/^,|,$/, "");
        chrome.storage.local.set({toolbarListKey: toolbarList});
        getToolbarList(toolbarList);
  } }

  function reloadHeader() {
    let div1 = $c("div", {className: "button-toolbar reload-header"},
        [{type:"click", fn:()=> resetHeader()}]),
        mainBar = $q(".toolbar.toolbar-droptarget.toolbar-mainbar");
    if ($q(".reload-header")) return;
    try {
      div1.innerHTML = '\
        <button id="reload-header" \
                class="ToolbarButton-Button custom-button" \
                title="'+ reloadHeaderTooltip +'" \
                type="button" \
                tabindex="-1">\
          <span>\
            <svg xmlns="http://www.w3.org/2000/svg" \
                 style="'+ reloadHeaderIcon +'"/>\
          </span>\
        </button>';
      mainBar.insertBefore(div1, mainBar.lastChild);
    } catch(ex) {}
  }

  function removeDupes(className) {
    let dupe = document.getElementsByClassName(className);
    if(dupe.length > 1) 
      for(var i = 1; i < dupe.length; i++) 
        dupe[i].parentNode.removeChild(dupe[i]);
  }

  function resetHeader() {
    let header = $q("#header"),
        main = $q("#main"),
        tabs = $q(".tab-strip"),
        footer = $q("footer");
    try {
      if (toolbarList) {
        let list =  toolbarList.replace(/\s+/g, "")
                               .replace(/^,|,$/, "")
                               .split(",");
        for (let i = list.length - 1; i >= 0; i--)
          main.insertBefore($q(list[i]), main.firstChild);
        if (tabsOnBottom) {
          main.insertBefore(tabs, main.lastChild);
          $i(footer, header.firstChild);
      } }
      homeToRestart(homeRestart);
      reloadHeader();
      optionsMenu();
    } catch(ex) {}
    buttonPopupListener();
  }

  function tabbarToggle(e) {
    let browser = $q("#browser"),
        header = $q("#header"),
        main = $q("#main"),
        res = $q(".resize"),
        tabs = $q(".tab-strip"),
        footer = $q("footer");
    try {
      chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
      if (e) {
        browser.setAttribute("tabs-on-bottom", true);
        main.insertBefore(tabs, main.lastChild);
        $i(footer, header.firstChild);
      } else {
        browser.removeAttribute("tabs-on-bottom");
        if (toolbarList) {
          let list =  toolbarList.replace(/\s+/g, "")
                                 .replace(/^,|,$/, "")
                                 .split(",");
          for (let i = list.length - 1; i >= 0; i--)
            main.insertBefore($q(list[i]), main.firstChild);
        }
        res.appendChild(tabs);
      }
    } catch(ex) {}
  }

  function onClose() {
    chrome.tabs.onActivated.removeListener(e => moveTabPosition(e));
    chrome.tabs.onHighlighted.removeListener((tabId, changeInfo, tab) =>
      getCurrentTab());
    chrome.tabs.onUpdated.removeListener((tabId, changeInfo, tab) => {
      if (tab.status === "complete") {
        getCurrentTabUpdated();
        clearInterval(favTimer);
      }
    });
  }

  function onResize() {
    if (!window.fullscreen) resetHeader();
    removeDupes("options-menu");
    resetHeader();
  }

  chrome.storage.local.get(['buttonPopupKey'], result => {
    buttonPopup = result.buttonPopupKey;
    customPopup(buttonPopup);
  });

  chrome.storage.local.get(['closeButtonKey'], result => {
    closeButton = result.closeButtonKey;
    customClose(closeButton);
  });

  chrome.storage.local.get(['favInUrlKey'], result => {
    favInUrl = result.favInUrlKey;
    favImage(favInUrl);
  });

  chrome.storage.local.get(['folderIconKey'], result => {
    folderIcon = result.folderIconKey;
    customFolder(folderIcon);
  });

  chrome.storage.local.get(['homeRestartKey'], result => {
    homeRestart = result.homeRestartKey;
    homeToRestart(homeRestart);
  });

  chrome.storage.local.get(['moveActiveTabKey'], result => {
    moveActiveTab = result.moveActiveTabKey;
    moveTab(moveActiveTab);
  });

  chrome.storage.local.get(['spinnerStyleKey'], result => {
    spinnerStyle = result.spinnerStyleKey;
    customSpinner(spinnerStyle);
  });

  chrome.storage.local.get(['tabsOnBottomKey'], result => {
    tabsOnBottom = result.tabsOnBottomKey;
  });

  chrome.storage.local.get(['toolbarListKey'], result => {
    toolbarList = result.toolbarListKey;
  });

  chrome.tabs.onActivated.addListener(e => moveTabPosition(e));

  chrome.tabs.onHighlighted.addListener((tabId, changeInfo, tab) =>
    getCurrentTab());

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.status === "complete") {
      getCurrentTabUpdated();
      clearInterval(favTimer);
    }
  });

  window.onload = () => setTimeout(() => {
    chrome.storage.local.get(['moveActiveTabKey'], result => {
      moveActiveTab = result.moveActiveTabKey;
      moveTab(moveActiveTab);
    });
    chrome.storage.local.get(['spinnerStyleKey'], result => {
      spinnerStyle = result.spinnerStyleKey;
      customSpinner(spinnerStyle);
    });
    chrome.storage.local.get(['tabsOnBottomKey'], result => {
      tabsOnBottom = result.tabsOnBottomKey;
      tabbarToggle(tabsOnBottom);
    });
    chrome.storage.local.get(['toolbarListKey'], result => {
      toolbarList = result.toolbarListKey;
      getToolbarList(toolbarList);
    });
    initialize()}, initializeDelay);

  window.onresize = () => setTimeout(() => onResize(), resizeDelay);

  window.ondrop = e => {
    e.preventDefault();
    homeToRestart(homeRestart);
  };

  window.onunload = () => {
    chrome.storage.local.set({buttonPopupKey: buttonPopup});
    chrome.storage.local.set({closeButtonKey: closeButton});
    chrome.storage.local.set({favInUrlKey: favInUrl});
    chrome.storage.local.set({folderIconKey: folderIcon});
    chrome.storage.local.set({homeRestartKey: homeRestart});
    chrome.storage.local.set({moveActiveTabKey: moveActiveTab});
    chrome.storage.local.set({spinnerStyleKey: spinnerStyle});
    chrome.storage.local.set({tabsOnBottomKey: tabsOnBottom});
    chrome.storage.local.set({toolbarListKey: toolbarList});
    onClose();
  };

})();
